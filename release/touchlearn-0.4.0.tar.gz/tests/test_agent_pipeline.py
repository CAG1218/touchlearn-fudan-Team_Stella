from __future__ import annotations

import base64
import json
import os
import re
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tests import EXAMPLES  # noqa: F401  (ensures src is on sys.path)

from touchlearn.agent.agent import TouchLearnAgent
from touchlearn.agent.router import RouteDecision
from touchlearn.agent.scene import SceneGeneration
from touchlearn.layout import build_layout
from touchlearn.model import diagram_from_dict
from touchlearn.paper import PAPER_ORDER
from touchlearn.schema import has_errors, validate_payload

SELECTION_ENV = {
    "TOUCHLEARN_LLM_PROVIDER": "tokenhub",
    "TOUCHLEARN_LLM_URL": "",
    "TOUCHLEARN_LLM_KEY": "sk-test",
    "TOUCHLEARN_LLM_MODEL": "deepseek-v4.1-flash",
    "TOUCHLEARN_VLM_PROVIDER": "",
    "TOUCHLEARN_VLM_URL": "",
    "TOUCHLEARN_VLM_KEY": "",
    "TOUCHLEARN_VLM_MODEL": "",
    "TOUCHLEARN_LLM_EFFORT": "",
    "TOUCHLEARN_SCENE_MODEL": "",
    "TOUCHLEARN_SCENE_EFFORT": "",
}


class AgentPipelineTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.agent = TouchLearnAgent(output_root=Path(self.temp.name))

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_auto_route_to_scene_with_offline_template(self) -> None:
        draft = self.agent.analyze(
            {
                "subject": "auto",
                "text": "画一个串联电路示意图：电池、开关、电阻和灯泡依次连接成回路。",
            }
        )
        self.assertEqual(draft["subject"], "scene")
        self.assertTrue(draft["ready"])
        self.assertEqual(draft["fields"]["template"], "circuit")
        self.assertEqual(draft["fields"]["summary"]["block_count"], 5)
        self.assertTrue(draft["fields"]["scene"]["blocks"])
        self.assertEqual(draft["fields"]["routing"]["subject"], "scene")

    def test_scene_build_writes_printable_bundle(self) -> None:
        draft = self.agent.analyze({"subject": "auto", "text": "画一个水循环流程图：蒸发、凝结、降水、收集。"})
        self.assertEqual(draft["subject"], "scene")
        with patch("touchlearn.agent.agent.synthesize_speech", return_value=(False, "test environment", None)):
            result = self.agent.build(draft["id"], public_base_url="http://127.0.0.1:8765")
        job_dir = Path(self.temp.name) / "jobs" / result["job_id"]
        self.assertTrue((job_dir / "model.stl").is_file())
        self.assertTrue((job_dir / "preview.svg").is_file())
        self.assertTrue((job_dir / "diagram.json").is_file())
        self.assertTrue((job_dir / "audio_script.txt").is_file())
        self.assertTrue((job_dir / "braille_map.md").is_file())
        map_text = (job_dir / "braille_map.md").read_text(encoding="utf-8")
        self.assertIn("GF 0019-2018", map_text)
        report = json.loads((job_dir / "compliance.json").read_text(encoding="utf-8"))
        self.assertTrue(report["printable"])
        self.assertEqual(report["counts"].get("FAIL", 0), 0)
        manifest = json.loads((job_dir / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["subject"], "scene")
        self.assertEqual(manifest["mode"], "tactile_plate")
        self.assertIn("scene_summary", manifest["geometry"])
        script = (job_dir / "audio_script.txt").read_text(encoding="utf-8")
        self.assertIn("编号 1", script)
        diagram = json.loads((job_dir / "diagram.json").read_text(encoding="utf-8"))
        issues = validate_payload(diagram)
        self.assertFalse(has_errors(issues), msg=[issue.to_dict() for issue in issues])

    def test_chinese_plate_reports_cell_pitch_print_clearance(self) -> None:
        draft = self.agent.analyze({"subject": "function", "expression": "x^2-2x-3", "paper": "A4"})
        with patch(
            "touchlearn.agent.agent.synthesize_speech", return_value=(False, "test environment", None)
        ):
            result = self.agent.build(draft["id"], public_base_url="http://127.0.0.1:8765")
        job_dir = Path(self.temp.name) / "jobs" / result["job_id"]
        report = json.loads((job_dir / "compliance.json").read_text(encoding="utf-8"))
        rules = {check["rule_id"]: check for check in report["checks"]}
        self.assertIn("braille.cell_pitch", rules)
        self.assertEqual(rules["braille.cell_pitch"]["status"], "DEVIATION")
        self.assertIn("6.90", rules["braille.cell_pitch"]["measured"])
        self.assertIn("0.1 mm", rules["braille.cell_pitch"]["message"])
        self.assertTrue(report["printable"])

    def test_robot_volume_nameplate_uses_chinese_braille(self) -> None:
        draft = self.agent.analyze(
            {
                "subject": "robot",
                "dof": 6,
                "link_length_mm": 90,
                "end_effector": "gripper",
                "output_mode": "volume",
                "target_height_mm": 150,
            }
        )
        self.assertTrue(draft["ready"], msg=draft.get("questions"))
        with patch(
            "touchlearn.agent.agent.synthesize_speech", return_value=(False, "test environment", None)
        ):
            result = self.agent.build(draft["id"], public_base_url="http://127.0.0.1:8765")
        job_dir = Path(self.temp.name) / "jobs" / result["job_id"]
        manifest = json.loads((job_dir / "manifest.json").read_text(encoding="utf-8"))
        nameplate = manifest["geometry"]["meta"]["nameplate"]
        self.assertEqual(nameplate["braille"], "机械臂")
        # A raised Latin nameplate cannot be read by touch, so the model no
        # longer carries an English "print" variant.
        self.assertNotIn("print", nameplate)

    def test_explicit_paper_reaches_every_plate_builder(self) -> None:
        cases = [
            ({"subject": "function", "expression": "x^2-2x-3", "paper": "A4"}, "A4"),
            ({"subject": "scene", "template": "triangle", "paper": "B4"}, "B4"),
            (
                {
                    "subject": "robot",
                    "dof": 6,
                    "end_effector": "gripper",
                    "output_mode": "relief",
                    "paper": "B4",
                },
                "B4",
            ),
        ]
        for payload, expected in cases:
            with self.subTest(subject=payload["subject"]):
                draft = self.agent.analyze(payload)
                self.assertTrue(draft["ready"], msg=draft.get("questions"))
                self.assertEqual(draft["fields"].get("paper"), expected)
                with patch(
                    "touchlearn.agent.agent.synthesize_speech",
                    return_value=(False, "test environment", None),
                ):
                    result = self.agent.build(draft["id"], public_base_url="http://127.0.0.1:8765")
                job_dir = Path(self.temp.name) / "jobs" / result["job_id"]
                diagram = json.loads((job_dir / "diagram.json").read_text(encoding="utf-8"))
                self.assertEqual(diagram["canvas"]["size"], expected)
                report = json.loads((job_dir / "compliance.json").read_text(encoding="utf-8"))
                self.assertTrue(report["printable"])

    def test_auto_paper_grows_past_a5_for_chinese_braille_labels(self) -> None:
        draft = self.agent.analyze({"subject": "scene", "template": "flowchart"})
        self.assertTrue(draft["ready"])
        self.assertEqual(draft["fields"].get("paper"), "")
        with patch(
            "touchlearn.agent.agent.synthesize_speech",
            return_value=(False, "test environment", None),
        ):
            result = self.agent.build(draft["id"], public_base_url="http://127.0.0.1:8765")
        job_dir = Path(self.temp.name) / "jobs" / result["job_id"]
        diagram = json.loads((job_dir / "diagram.json").read_text(encoding="utf-8"))
        paper = diagram["canvas"]["size"]
        self.assertIn(paper, PAPER_ORDER)
        # Every block carries a Chinese braille label, so the automatic size
        # has to leave A5 rather than crowd the 2 mm clearances.
        self.assertGreater(PAPER_ORDER.index(paper), PAPER_ORDER.index("A5"))
        report = json.loads((job_dir / "compliance.json").read_text(encoding="utf-8"))
        self.assertTrue(report["printable"])
        self.assertEqual(report["counts"].get("FAIL", 0), 0)

    def test_edge_audio_is_recorded_and_wired_into_the_page(self) -> None:
        draft = self.agent.analyze({"subject": "auto", "text": "请画函数 y=x^2-2x-3 的图像"})

        def fake_speech(text: str, job_dir: object) -> tuple[bool, str, str]:
            (Path(job_dir) / "narration.mp3").write_bytes(b"ID3" + b"\x00" * 2048)
            return True, "edge ok", "narration.mp3"

        with patch("touchlearn.agent.agent.synthesize_speech", side_effect=fake_speech):
            result = self.agent.build(draft["id"], public_base_url="http://127.0.0.1:8765")
        job_dir = Path(self.temp.name) / "jobs" / result["job_id"]
        manifest = json.loads((job_dir / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["audio"]["audio_file"], "narration.mp3")
        self.assertEqual(manifest["audio"]["audio_format"], "mp3")
        self.assertEqual(manifest["audio"]["engine"], "edge-tts")
        self.assertTrue(manifest["audio"]["wav_ready"])
        page = (job_dir / "audio.html").read_text(encoding="utf-8")
        self.assertIn('src="narration.mp3"', page)
        self.assertIn("下载音频", page)
        report = json.loads((job_dir / "compliance.json").read_text(encoding="utf-8"))
        check = next(item for item in report["checks"] if item["rule_id"] == "audio.script")
        self.assertEqual(check["status"], "PASS")

    def test_auto_function_from_text(self) -> None:
        draft = self.agent.analyze({"subject": "auto", "text": "请画函数 y=x^2-2x-3 的图像"})
        self.assertEqual(draft["subject"], "function")
        self.assertTrue(draft["ready"])
        self.assertIn("X^2-2X-3", draft["fields"]["expression"])

    def test_uploaded_text_document_drives_function_draft(self) -> None:
        content = "课堂练习：请画出函数 y=x^2-2x-3 的图像，并标出零点。".encode("utf-8")
        draft = self.agent.analyze(
            {
                "subject": "auto",
                "files": [{"name": "worksheet.txt", "data": base64.b64encode(content).decode("ascii")}],
            }
        )
        self.assertEqual(draft["subject"], "function")
        self.assertTrue(draft["ready"])
        self.assertIn("X^2-2X-3", draft["fields"]["expression"])
        self.assertEqual(draft["files"][0]["document"]["ok"], True)

    def test_uploaded_file_with_chinese_name_keeps_extension(self) -> None:
        content = "课堂练习：请画出函数 y=x^2-2x-3 的图像。".encode("utf-8")
        draft = self.agent.analyze(
            {
                "subject": "auto",
                "files": [{"name": "路线图.txt", "data": base64.b64encode(content).decode("ascii")}],
            }
        )
        uploaded = draft["files"][0]
        self.assertEqual(uploaded["extension"], ".txt")
        self.assertEqual(uploaded["name"], "路线图.txt")
        self.assertEqual(uploaded["document"]["ok"], True)

    def test_uploaded_image_with_chinese_name_is_accepted(self) -> None:
        draft = self.agent.analyze(
            {
                "subject": "auto",
                "files": [{"name": "尾翼图.png", "data": base64.b64encode(b"not-a-real-png").decode("ascii")}],
            }
        )
        uploaded = draft["files"][0]
        self.assertEqual(uploaded["extension"], ".png")
        self.assertEqual(uploaded["name"], "尾翼图.png")

    def test_uploaded_scene_json_is_used_directly(self) -> None:
        scene = {
            "title": "CUSTOM SCENE",
            "blocks": [
                {
                    "id": "circle",
                    "label": "CIRCLE",
                    "label_zh": "圆",
                    "primitives": [{"type": "circle", "cx": 50, "cy": 50, "r": 20}],
                }
            ],
        }
        content = json.dumps(scene, ensure_ascii=False).encode("utf-8")
        draft = self.agent.analyze(
            {
                "subject": "auto",
                "files": [{"name": "scene.json", "data": base64.b64encode(content).decode("ascii")}],
            }
        )
        self.assertEqual(draft["subject"], "scene")
        self.assertTrue(draft["ready"])
        self.assertEqual(draft["fields"]["summary"]["block_count"], 1)
        self.assertTrue(any("scene.json" in note for note in draft["notes"]))

    def test_unsupported_request_is_refused(self) -> None:
        draft = self.agent.analyze({"subject": "auto", "text": "帮我写一篇关于春天的作文"})
        self.assertEqual(draft["subject"], "unsupported")
        self.assertFalse(draft["ready"])
        self.assertTrue(draft["questions"])

    def test_explicit_template_without_text(self) -> None:
        draft = self.agent.analyze({"subject": "auto", "template": "pythagorean"})
        self.assertEqual(draft["subject"], "scene")
        self.assertTrue(draft["ready"])
        self.assertEqual(draft["fields"]["template"], "pythagorean")

    def test_scene_title_override_reaches_build(self) -> None:
        draft = self.agent.analyze({"subject": "auto", "template": "triangle"})
        scene = dict(draft["fields"]["scene"])
        scene["title"] = "RIGHT TRIANGLE"
        with patch("touchlearn.agent.agent.synthesize_speech", return_value=(False, "test environment", None)):
            result = self.agent.build(
                draft["id"],
                overrides={"fields": {"scene": scene}},
                public_base_url="http://127.0.0.1:8765",
            )
        manifest = json.loads(
            (Path(self.temp.name) / "jobs" / result["job_id"] / "manifest.json").read_text(encoding="utf-8")
        )
        self.assertEqual(manifest["title"], "RIGHT TRIANGLE")

    def test_analyze_threads_selection_and_records_llm(self) -> None:
        decision = RouteDecision("function", 0.95, "test route")
        candidate = {
            "ok": True,
            "expression": "X^2-2X-3",
            "provider": "llm:tokenhub",
            "model": "glm-5.3",
            "confidence": 0.9,
        }
        with (
            patch.dict(os.environ, SELECTION_ENV, clear=False),
            patch("touchlearn.agent.agent.classify_request", return_value=decision) as classify,
            patch("touchlearn.agent.agent.extract_function", return_value=candidate) as extract,
        ):
            draft = self.agent.analyze(
                {
                    "subject": "auto",
                    "text": "画一个二次函数",
                    "model": "glm-5.3",
                    "effort": "high",
                }
            )
        classify_kwargs = classify.call_args.kwargs
        self.assertEqual(classify_kwargs["model"], "glm-5.3")
        self.assertEqual(classify_kwargs["effort"], "high")
        self.assertEqual(classify_kwargs["vision_model"], "deepseek/deepseek-flash")
        extract_kwargs = extract.call_args.kwargs
        self.assertEqual(extract_kwargs["model"], "glm-5.3")
        self.assertEqual(extract_kwargs["effort"], "high")
        self.assertEqual(draft["subject"], "function")
        self.assertEqual(draft["fields"]["llm"]["model"], "glm-5.3")
        self.assertEqual(draft["fields"]["llm"]["effort"], "high")
        self.assertTrue(draft["fields"]["llm"]["requested"])

    def test_analyze_records_the_initial_default(self) -> None:
        decision = RouteDecision("function", 0.95, "test route")
        candidate = {
            "ok": True,
            "expression": "sin(x)",
            "provider": "llm:tokenhub",
            "model": "deepseek-v4.1-flash",
            "confidence": 0.8,
        }
        with (
            patch.dict(os.environ, SELECTION_ENV, clear=False),
            patch("touchlearn.agent.agent.classify_request", return_value=decision),
            patch("touchlearn.agent.agent.extract_function", return_value=candidate),
        ):
            draft = self.agent.analyze({"subject": "auto", "text": "画一个正弦曲线"})
        self.assertEqual(draft["fields"]["llm"]["model"], "deepseek-v4.1-flash")
        self.assertEqual(draft["fields"]["llm"]["effort"], "low")
        self.assertFalse(draft["fields"]["llm"]["requested"])

    def test_analyze_rejects_an_unknown_model_before_calling_llm(self) -> None:
        with patch.dict(os.environ, SELECTION_ENV, clear=False):
            with self.assertRaisesRegex(ValueError, "不支持所选模型"):
                self.agent.analyze(
                    {
                        "subject": "auto",
                        "text": "画一个串联电路示意图",
                        "model": "not-offered",
                    }
                )

    def test_image_scene_uses_the_vision_model_from_the_selection(self) -> None:
        decision = RouteDecision("scene", 0.9, "test route")
        with (
            patch.dict(os.environ, SELECTION_ENV, clear=False),
            patch("touchlearn.agent.agent.classify_request", return_value=decision),
            patch(
                "touchlearn.agent.agent.generate_scene",
                return_value=SceneGeneration(False, message="stop"),
            ) as generate,
        ):
            self.agent.analyze(
                {
                    "subject": "auto",
                    "text": "把这张图简化成触觉示意图",
                    "files": [{"name": "drawing.png", "data": base64.b64encode(b"not-a-real-png").decode("ascii")}],
                    "model": "glm-5.3",
                    "effort": "medium",
                }
            )
        kwargs = generate.call_args.kwargs
        self.assertEqual(kwargs["model"], "deepseek/deepseek-flash")
        self.assertEqual(kwargs["effort"], "medium")

    def test_plates_use_braille_only_for_chinese_text(self) -> None:
        """Chinese prose is braille; mathematics keeps standard raised glyphs."""
        cases = [
            {"subject": "function", "expression": "x^2-2x-3", "paper": "A5"},
            {"subject": "scene", "template": "triangle", "paper": "A5"},
        ]
        for payload in cases:
            with self.subTest(subject=payload["subject"]):
                draft = self.agent.analyze(payload)
                self.assertTrue(draft["ready"], msg=draft.get("questions"))
                with patch(
                    "touchlearn.agent.agent.synthesize_speech",
                    return_value=(False, "test environment", None),
                ):
                    result = self.agent.build(
                        draft["id"], public_base_url="http://127.0.0.1:8765"
                    )
                job_dir = Path(self.temp.name) / "jobs" / result["job_id"]
                diagram = json.loads((job_dir / "diagram.json").read_text(encoding="utf-8"))
                layout = build_layout(diagram_from_dict(diagram))
                raised = [
                    primitive.text
                    for feature in layout.features
                    for primitive in feature.primitives
                    if primitive.kind == "text"
                ]
                braille_texts = [
                    primitive.text
                    for feature in layout.features
                    for primitive in feature.primitives
                    if primitive.kind == "braille"
                ]
                self.assertTrue(raised, "plate should carry standard raised notation")
                self.assertTrue(braille_texts, "plate should carry Chinese braille")
                for value in braille_texts:
                    self.assertRegex(
                        value,
                        r"[\u4e00-\u9fff]",
                        msg=f"braille is reserved for Chinese text, found {value!r}",
                    )
                if payload["subject"] == "function":
                    # The expression and each key-point coordinate stay in
                    # standard print instead of turning into dot patterns.
                    self.assertTrue(
                        any(value.startswith("Y=") for value in raised),
                        msg=f"equation should be standard raised text: {raised!r}",
                    )
                    self.assertTrue(
                        any(value.startswith("(") and value.endswith(")") for value in raised),
                        msg=f"key points should carry standard coordinates: {raised!r}",
                    )


if __name__ == "__main__":
    unittest.main()
