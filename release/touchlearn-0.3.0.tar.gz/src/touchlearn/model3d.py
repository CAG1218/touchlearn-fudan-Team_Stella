"""Deterministic 3D model compiler for the tactile-model mode.

The language model only describes *what* the model contains: parts, shapes,
relative sizes and relative positions.  This module owns *how* it is built:
millimetres, supports, orbit rings, base, braille plaques and printable shells.
That split keeps the result reproducible and stops a model from inventing a
millimetre dimension it cannot know.

Two entry points matter:

* :func:`plan_model3d` turns a request into a validated spec.  The solar-system
  case is compiled offline from a fixed catalogue, so the demo works without a
  network or an API key.
* :func:`build_model3d` turns the spec into a watertight STL.  Overlapping
  shells are intentional (the slicer unions them), exactly like the robot
  volumetric path.

Chinese labels use GF 0019-2018 encoding from :mod:`touchlearn.cnbraille`.
The solar-system model is deliberately *not* to scale: planet radii keep their
real order but are compressed so Mercury and Jupiter can both be touched.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Iterable, Sequence

from . import cnbraille
from .agent.llm import chat_json
from .agent.volumetric import (
    _add,
    _add_quad,
    _add_triangle,
    _box_xy,
    _cylinder,
    _mul,
    _prism_xy,
    _sphere,
    _sub,
    _unit,
)
from .geometry import Mesh, Primitive, primitive_polygons
from .layout import rect_polygon

Vec3 = tuple[float, float, float]
Point2 = tuple[float, float]

DEFAULT_BASE_RADIUS_MM = 102.0
BASE_THICKNESS_MM = 5.0
ORBIT_HEIGHT_MM = 1.2
BRAILLE_DOT_HEIGHT_MM = 0.8
SUPPORT_RADIUS_MM = 1.8
BUILD_VOLUME_MM = (220.0, 220.0, 250.0)
SHAPE_NAMES = {
    "sphere": "球体",
    "cylinder": "圆柱",
    "box": "长方体",
    "cone": "圆锥",
    "torus": "圆环",
    "plate": "薄板",
}

# Real equatorial radii relative to Earth.  They are used only for ordering and
# for the compression formula; the printed radii are in the catalogue below.
PLANETS: tuple[dict[str, Any], ...] = (
    {
        "id": "mercury",
        "name_zh": "水星",
        "name_en": "MERCURY",
        "relative_radius": 0.383,
        "orbit_mm": 38.0,
        "angle_deg": 200.0,
        "note": "离太阳最近，体积最小。",
    },
    {
        "id": "venus",
        "name_zh": "金星",
        "name_en": "VENUS",
        "relative_radius": 0.949,
        "orbit_mm": 46.0,
        "angle_deg": 248.0,
        "note": "大小和地球接近，表面被厚云层包住。",
    },
    {
        "id": "earth",
        "name_zh": "地球",
        "name_en": "EARTH",
        "relative_radius": 1.0,
        "orbit_mm": 54.0,
        "angle_deg": 296.0,
        "note": "目前已知有生命的行星。",
    },
    {
        "id": "mars",
        "name_zh": "火星",
        "name_en": "MARS",
        "relative_radius": 0.532,
        "orbit_mm": 62.0,
        "angle_deg": 344.0,
        "note": "比地球小，表面呈红色。",
    },
    {
        "id": "jupiter",
        "name_zh": "木星",
        "name_en": "JUPITER",
        "relative_radius": 11.21,
        "orbit_mm": 70.0,
        "angle_deg": 32.0,
        "note": "太阳系里最大的行星。",
    },
    {
        "id": "saturn",
        "name_zh": "土星",
        "name_en": "SATURN",
        "relative_radius": 9.45,
        "orbit_mm": 78.0,
        "angle_deg": 80.0,
        "note": "外面有一圈明显的光环。",
    },
    {
        "id": "uranus",
        "name_zh": "天王星",
        "name_en": "URANUS",
        "relative_radius": 4.01,
        "orbit_mm": 86.0,
        "angle_deg": 128.0,
        "note": "体积较大，自转轴倾斜得很厉害。",
    },
    {
        "id": "neptune",
        "name_zh": "海王星",
        "name_en": "NEPTUNE",
        "relative_radius": 3.88,
        "orbit_mm": 94.0,
        "angle_deg": 176.0,
        "note": "离太阳最远的行星。",
    },
)

SOLAR_KEYWORDS = ("太阳系", "行星", "轨道", "solar system", "planet", "orbit", "八大行星", "九大行星")


class Model3DError(ValueError):
    """Raised when a 3D spec cannot be compiled without inventing geometry."""


@dataclass
class Model3DPlan:
    ok: bool
    spec: dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0
    provider: str = ""
    model: str = ""
    message: str = ""
    notes: list[str] = field(default_factory=list)
    questions: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "kind": self.spec.get("kind"),
            "title": self.spec.get("title"),
            "title_zh": self.spec.get("title_zh"),
            "part_count": len(self.spec.get("parts") or []),
            "confidence": round(self.confidence, 3),
            "provider": self.provider,
            "model": self.model,
            "message": self.message,
            "notes": self.notes,
            "questions": self.questions,
        }


@dataclass
class Model3DResult:
    mesh: Mesh
    meta: dict[str, Any]


# ---------------------------------------------------------------------------
# Spec planning
# ---------------------------------------------------------------------------


def _wants_solar(text: str) -> bool:
    lowered = (text or "").lower()
    return any(keyword in lowered for keyword in SOLAR_KEYWORDS)


def _planet_count(text: str) -> int:
    if "八" in text or "8" in text:
        return 8
    if "七" in text or "7" in text:
        return 7
    return 7


def solar_system_spec(text: str = "") -> dict[str, Any]:
    count = max(1, min(len(PLANETS), _planet_count(text)))
    selected = PLANETS[:count]
    planets: list[dict[str, Any]] = []
    for index, entry in enumerate(selected):
        radius = compress_planet_radius(entry["relative_radius"])
        planets.append(
            {
                "id": entry["id"],
                "name_zh": entry["name_zh"],
                "name_en": entry["name_en"],
                "shape": "sphere",
                "relative_radius": entry["relative_radius"],
                "radius_mm": round(radius, 3),
                "orbit_mm": entry["orbit_mm"],
                "angle_deg": entry["angle_deg"],
                "order": index + 1,
                "note": entry["note"],
            }
        )
    return {
        "version": 1,
        "kind": "solar_system",
        "title": "SOLAR SYSTEM",
        "title_zh": "太阳系",
        "summary": f"太阳和 {count} 颗行星，行星位于同心类圆形轨道上，并带中文盲文名牌。",
        "base": {
            "shape": "disc",
            "radius_mm": DEFAULT_BASE_RADIUS_MM,
            "thickness_mm": BASE_THICKNESS_MM,
        },
        "sun": {"radius_mm": 20.0, "pedestal_mm": 6.0},
        "planets": planets,
        "planet_count": count,
        "scale_note": "行星半径按真实相对大小排序后压缩，保持大小顺序，不是等比例模型。",
        "source": "catalogue",
    }


def compress_planet_radius(relative: float) -> float:
    """Map a real relative radius into a printable 4.2-12.6 mm band.

    A power compression keeps the ordering (Jupiter > Saturn > Uranus > Earth >
    Venus > Mars > Mercury) while making every planet large enough for a
    support post and a readable silhouette.
    """
    maximum = max(entry["relative_radius"] for entry in PLANETS)
    ratio = max(0.0, relative) / maximum
    return 4.2 + (ratio ** 0.42) * 8.4


def _number(value: Any, *, low: float, high: float, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise Model3DError(f"{label} 必须是数字。")
    number = float(value)
    if not math.isfinite(number):
        raise Model3DError(f"{label} 不是有限数字。")
    return max(low, min(high, number))


def normalize_model_spec(raw: Any) -> tuple[dict[str, Any], list[str]]:
    """Validate an LLM or catalogue spec without inventing missing parts."""
    if not isinstance(raw, dict):
        raise Model3DError("三维模型规格必须是 JSON 对象。")
    kind = str(raw.get("kind") or "assembly").strip().lower()
    if kind == "solar_system":
        text = str(raw.get("request") or raw.get("summary") or "")
        spec = solar_system_spec(text)
        return spec, []
    title = str(raw.get("title") or "TACTILE 3D MODEL").strip()[:48]
    title_zh = str(raw.get("title_zh") or title).strip()[:48]
    parts_raw = raw.get("parts")
    if not isinstance(parts_raw, list) or not parts_raw:
        raise Model3DError("三维模型至少需要一个 parts 部件。")
    parts: list[dict[str, Any]] = []
    warnings: list[str] = []
    for index, item in enumerate(parts_raw[:24]):
        if not isinstance(item, dict):
            continue
        shape = str(item.get("shape") or "").strip().lower()
        if shape not in {"sphere", "cylinder", "box", "cone", "torus", "plate"}:
            warnings.append(f"部件 {index + 1} 的形状 {shape or '空'} 不支持，已跳过。")
            continue
        label_zh = str(item.get("name_zh") or item.get("label_zh") or item.get("label") or f"部件{index + 1}").strip()[:24]
        size = item.get("size", 20)
        if isinstance(size, (list, tuple)):
            size_value = [_number(value, low=1.0, high=100.0, label="size") for value in size[:3]]
        else:
            scalar = _number(size, low=1.0, high=100.0, label="size")
            size_value = [scalar, scalar, scalar]
        position = item.get("position", [50, 50, 0])
        if not isinstance(position, (list, tuple)) or len(position) < 2:
            position = [50, 50, 0]
        pos = [
            _number(position[0], low=0.0, high=100.0, label="position"),
            _number(position[1], low=0.0, high=100.0, label="position"),
            _number(position[2] if len(position) > 2 else 0.0, low=0.0, high=100.0, label="position"),
        ]
        parts.append(
            {
                "id": str(item.get("id") or f"part_{index + 1}").strip()[:32],
                "name_zh": label_zh,
                "name_en": str(item.get("label") or item.get("name_en") or "").strip()[:32],
                "shape": shape,
                "size": size_value,
                "position": pos,
                "rotation_deg": _number(item.get("rotation_deg", 0), low=-180.0, high=180.0, label="rotation_deg"),
                "note": str(item.get("note") or "").strip()[:160],
            }
        )
    if not parts:
        raise Model3DError("没有可编译的三维部件。")
    spec = {
        "version": 1,
        "kind": "assembly",
        "title": title,
        "title_zh": title_zh,
        "summary": str(raw.get("summary") or "").strip()[:240],
        "base": {
            "shape": "disc",
            "radius_mm": _number((raw.get("base") or {}).get("radius_mm", 90), low=30, high=110, label="base.radius_mm"),
            "thickness_mm": _number((raw.get("base") or {}).get("thickness_mm", 4), low=2, high=10, label="base.thickness_mm"),
        },
        "parts": parts,
        "scale_note": str(raw.get("scale_note") or "部件大小为相对比例，不是工程尺寸。").strip()[:160],
        "source": str(raw.get("source") or "llm")[:32],
    }
    return spec, warnings


MODEL3D_SYSTEM = (
    "你是触觉三维模型的结构设计助手。你把用户的建模需求转成严格 JSON，供确定性几何编译器生成可打印 STL。"
    "只输出 JSON 对象，不要 Markdown，不要解释。不要输出毫米绝对值；部件大小用 1-100 的相对值，"
    "位置用 0-100 的相对坐标（x 向右，y 向后，z 向上）。不要编造用户没有提供的事实；"
    "无法可靠建模时返回 supported=false 并说明原因。"
)

MODEL3D_PROMPT = """请把下面的需求转成触觉三维模型 JSON。

用户需求：
{request}

已有提示：
{hint}

输出结构：
{{
  "supported": true,
  "kind": "assembly",
  "title": "英文标题",
  "title_zh": "中文标题",
  "summary": "一句中文说明",
  "base": {{"shape": "disc", "radius_mm": 90, "thickness_mm": 4}},
  "parts": [
    {{
      "id": "part_1",
      "name_zh": "部件中文名",
      "label": "PART 1",
      "shape": "sphere|cylinder|box|cone|torus|plate",
      "size": [20, 20, 20],
      "position": [50, 50, 20],
      "rotation_deg": 0,
      "note": "触摸说明"
    }}
  ],
  "scale_note": "相对比例说明",
  "notes": ["制作说明"],
  "questions": ["需要用户确认的点"]
}}

规则：
1. 每个部件必须有形状、相对大小和相对位置；不要给出真实毫米尺寸。
2. 部件数量 1-24；只表达能可靠触摸的主要结构，不要逐像素还原照片。
3. 需要底座时在 base 中说明；没有底座时仍会生成一个薄底板以保证可打印。
4. 中文名称会转成 GF 0019-2018 中文盲文；名称要短（建议 2-4 个字）。
5. 如果需求是太阳系，kind 写 solar_system，并让编译器使用内置行星目录。
6. 无法可靠建模时返回 {{"supported": false, "reason": "原因"}}。
"""


def plan_model3d(
    text: str,
    *,
    images: Sequence[str] | None = None,
    hint: str = "",
    model: str | None = None,
    effort: str | None = None,
) -> Model3DPlan:
    request = (text or "").strip()
    if _wants_solar(request):
        spec = solar_system_spec(request)
        return Model3DPlan(
            True,
            spec=spec,
            confidence=0.92,
            provider="catalogue",
            message="已用内置太阳系目录生成三维规格；行星大小按真实顺序压缩。",
            notes=[
                "行星轨道是底座上的同心圆环，行星由立柱支撑在轨道上方。",
                "每颗行星外侧有竖立的盲文名牌，底座上有标题盲文和二维码平台。",
                "行星半径保持真实大小顺序，但经过压缩；不是等比例模型。",
            ],
            questions=["请确认行星数量、中文名称和盲文名牌方向。"],
        )

    if not request and not images:
        return Model3DPlan(False, message="请描述要生成的三维模型。", questions=["例如：太阳系、地球仪、分子结构、火箭。"])
    prompt = MODEL3D_PROMPT.format(request=request[:4000], hint=(hint or "无")[:600])
    result = chat_json(
        MODEL3D_SYSTEM,
        prompt,
        images=images or (),
        kind="vision" if images else "text",
        max_tokens=4096,
        model=model,
        effort=effort,
    )
    if not result.ok:
        return Model3DPlan(
            False,
            provider=result.provider,
            model=result.model,
            message=result.message,
            questions=["当前没有可用的大模型来理解这个三维需求；可以换成“太阳系”示例，或配置模型后重试。"],
        )
    data = result.data if isinstance(result.data, dict) else None
    if data is None:
        return Model3DPlan(False, provider=result.provider, model=result.model, message="模型返回的不是 JSON 对象。")
    if data.get("supported") is False:
        return Model3DPlan(
            False,
            provider=result.provider,
            model=result.model,
            message=str(data.get("reason") or "模型判断该需求不适合三维建模。"),
        )
    try:
        spec, warnings = normalize_model_spec(data)
    except Model3DError as error:
        return Model3DPlan(False, provider=result.provider, model=result.model, message=str(error))
    notes = [str(item).strip()[:180] for item in (data.get("notes") or []) if isinstance(item, str) and item.strip()][:5]
    questions = [str(item).strip()[:180] for item in (data.get("questions") or []) if isinstance(item, str) and item.strip()][:5]
    confidence = data.get("confidence", 0.65)
    try:
        confidence = max(0.0, min(1.0, float(confidence)))
    except (TypeError, ValueError):
        confidence = 0.65
    return Model3DPlan(
        True,
        spec=spec,
        confidence=confidence,
        provider=result.provider,
        model=result.model,
        message="大模型已生成三维结构候选；几何由本地编译器确定。",
        notes=notes + warnings,
        questions=questions,
    )


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------


def _ring(mesh: Mesh, centre: Point2, outer: float, inner: float, z0: float, z1: float, segments: int = 64) -> None:
    if outer <= inner or outer <= 0:
        return
    top = z1
    bottom = z0
    outer_bottom: list[Vec3] = []
    outer_top: list[Vec3] = []
    inner_bottom: list[Vec3] = []
    inner_top: list[Vec3] = []
    for index in range(segments):
        angle = 2.0 * math.pi * index / segments
        cos_a, sin_a = math.cos(angle), math.sin(angle)
        outer_bottom.append((centre[0] + outer * cos_a, centre[1] + outer * sin_a, bottom))
        outer_top.append((centre[0] + outer * cos_a, centre[1] + outer * sin_a, top))
        inner_bottom.append((centre[0] + inner * cos_a, centre[1] + inner * sin_a, bottom))
        inner_top.append((centre[0] + inner * cos_a, centre[1] + inner * sin_a, top))
    centre_top = (centre[0], centre[1], top + 1.0)
    centre_bottom = (centre[0], centre[1], bottom - 1.0)
    for index in range(segments):
        nxt = (index + 1) % segments
        _add_quad(mesh, outer_top[index], outer_top[nxt], inner_top[nxt], inner_top[index], centre_top)
        _add_quad(mesh, outer_bottom[nxt], outer_bottom[index], inner_bottom[index], inner_bottom[nxt], centre_bottom)
        _add_quad(
            mesh,
            outer_bottom[index],
            outer_bottom[nxt],
            outer_top[nxt],
            outer_top[index],
            ((outer_bottom[index][0] + outer_bottom[nxt][0]) / 2 - centre[0], (outer_bottom[index][1] + outer_bottom[nxt][1]) / 2 - centre[1], 0.0),
        )
        _add_quad(
            mesh,
            inner_bottom[nxt],
            inner_bottom[index],
            inner_top[index],
            inner_top[nxt],
            (centre[0] - (inner_bottom[index][0] + inner_bottom[nxt][0]) / 2, centre[1] - (inner_bottom[index][1] + inner_bottom[nxt][1]) / 2, 0.0),
        )


def _base_outline(radius: float, tab_front: float) -> list[Point2]:
    """Round display base with a front tab for the title and QR pads.

    A pure disc has no flat land outside the outer orbit, so the pads would
    overhang the rim.  The tab keeps both pads fully supported without making
    the whole model a square block.
    """
    join_y = -0.68 * radius
    join_x = math.sqrt(max(radius * radius - join_y * join_y, 1.0))
    half = max(20.0, join_x - 1.5)
    start = math.atan2(join_y, join_x)
    end = math.pi - start
    steps = 72
    points: list[Point2] = []
    for index in range(steps + 1):
        angle = start + (end - start) * index / steps
        points.append((radius * math.cos(angle), radius * math.sin(angle)))
    points.append((-half, tab_front))
    points.append((half, tab_front))
    return points


def _frustum(mesh: Mesh, p0: Vec3, p1: Vec3, r0: float, r1: float, segments: int = 28) -> None:
    if r0 <= 0 and r1 <= 0:
        return
    axis = _sub(p1, p0)
    length = math.sqrt(axis[0] ** 2 + axis[1] ** 2 + axis[2] ** 2)
    if length <= 1e-9:
        return
    w = _unit(axis)
    helper = (0.0, 0.0, 1.0) if abs(w[2]) < 0.9 else (1.0, 0.0, 0.0)
    u = _unit((w[1] * helper[2] - w[2] * helper[1], w[2] * helper[0] - w[0] * helper[2], w[0] * helper[1] - w[1] * helper[0]))
    v = (w[1] * u[2] - w[2] * u[1], w[2] * u[0] - w[0] * u[2], w[0] * u[1] - w[1] * u[0])
    ring0: list[Vec3] = []
    ring1: list[Vec3] = []
    for index in range(segments):
        angle = 2.0 * math.pi * index / segments
        offset0 = _add(_mul(u, r0 * math.cos(angle)), _mul(v, r0 * math.sin(angle)))
        offset1 = _add(_mul(u, r1 * math.cos(angle)), _mul(v, r1 * math.sin(angle)))
        ring0.append(_add(p0, offset0))
        ring1.append(_add(p1, offset1))
    centre = _mul(_add(p0, p1), 0.5)
    for index in range(segments):
        nxt = (index + 1) % segments
        if r0 > 0 and r1 > 0:
            _add_quad(mesh, ring0[index], ring0[nxt], ring1[nxt], ring1[index], centre)
        elif r1 == 0:
            _add_triangle(mesh, ring0[index], ring0[nxt], p1, _sub(p1, centre))
        else:
            _add_triangle(mesh, ring1[nxt], ring1[index], p0, _sub(p0, centre))
    if r0 > 0:
        for index in range(segments):
            nxt = (index + 1) % segments
            _add_triangle(mesh, p0, ring0[nxt], ring0[index], _sub(p0, centre))
    if r1 > 0:
        for index in range(segments):
            nxt = (index + 1) % segments
            _add_triangle(mesh, p1, ring1[index], ring1[nxt], _sub(p1, centre))


@dataclass(frozen=True)
class Frame:
    origin: Vec3
    u: Vec3
    v: Vec3
    w: Vec3

    def point(self, du: float, dv: float, dw: float) -> Vec3:
        return (
            self.origin[0] + self.u[0] * du + self.v[0] * dv + self.w[0] * dw,
            self.origin[1] + self.u[1] * du + self.v[1] * dv + self.w[1] * dw,
            self.origin[2] + self.u[2] * du + self.v[2] * dv + self.w[2] * dw,
        )


def _oriented_plate(mesh: Mesh, frame: Frame, width: float, height: float, thickness: float) -> None:
    hw, hh, ht = width / 2.0, height / 2.0, thickness / 2.0
    corners = [
        frame.point(-hw, -hh, -ht),
        frame.point(hw, -hh, -ht),
        frame.point(hw, hh, -ht),
        frame.point(-hw, hh, -ht),
        frame.point(-hw, -hh, ht),
        frame.point(hw, -hh, ht),
        frame.point(hw, hh, ht),
        frame.point(-hw, hh, ht),
    ]
    centre = frame.origin
    for indices, hint in (
        ((4, 5, 6, 7), frame.w),
        ((1, 0, 3, 2), _mul(frame.w, -1.0)),
        ((0, 1, 5, 4), _mul(frame.v, -1.0)),
        ((2, 3, 7, 6), frame.v),
        ((0, 4, 7, 3), _mul(frame.u, -1.0)),
        ((1, 2, 6, 5), frame.u),
    ):
        a, b, c, d = (corners[index] for index in indices)
        _add_quad(mesh, a, b, c, d, hint)


def _braille_on_plate(
    mesh: Mesh,
    frame: Frame,
    text: str,
    width: float,
    height: float,
    thickness: float,
    *,
    dot_height: float = BRAILLE_DOT_HEIGHT_MM,
) -> list[tuple[Vec3, float]]:
    text_width = cnbraille.width(text, syllable_gap_mm=cnbraille.SYLLABLE_GAP_MM)
    text_height = cnbraille.height()
    if text_width > width - 2.0:
        raise Model3DError(f"盲文 {text!r} 宽 {text_width:.1f} mm，放不进 {width:.1f} mm 的名牌。")
    origin_u = -width / 2.0 + (width - text_width) / 2.0
    origin_v = height / 2.0 - (height - text_height) / 2.0
    dots = cnbraille.dot_centers(text, 0.0, 0.0)
    placed: list[tuple[Vec3, float]] = []
    for x, y in dots:
        du = origin_u + x
        dv = origin_v - y
        start = frame.point(du, dv, thickness / 2.0 - 0.12)
        end = frame.point(du, dv, thickness / 2.0 + dot_height)
        _cylinder(mesh, start, end, cnbraille.DOT_DIAMETER_MM / 2.0, segments=12)
        placed.append((start, cnbraille.DOT_DIAMETER_MM / 2.0))
    return placed


def _braille_on_top(mesh: Mesh, text: str, x: float, y: float, z0: float, z1: float) -> None:
    for dot_x, dot_y in cnbraille.dot_centers(text, x, y):
        _cylinder(mesh, (dot_x, dot_y, z0 - 0.1), (dot_x, dot_y, z1), cnbraille.DOT_DIAMETER_MM / 2.0, segments=12)


def _emboss_text_on_top(mesh: Mesh, text: str, x: float, y: float, z0: float, z1: float, height: float) -> None:
    primitive = Primitive("text", ((x, y),), text=text, height=height)
    for polygon in primitive_polygons(primitive):
        _prism_xy(mesh, polygon, z0, z1)


# ---------------------------------------------------------------------------
# Solar-system compiler
# ---------------------------------------------------------------------------


def _solar_system_mesh(spec: dict[str, Any]) -> Model3DResult:
    mesh = Mesh([])
    base = spec.get("base") or {}
    base_radius = float(base.get("radius_mm") or DEFAULT_BASE_RADIUS_MM)
    base_thickness = float(base.get("thickness_mm") or BASE_THICKNESS_MM)
    top = base_thickness
    tab_front = -(base_radius + 16.0)

    # Round body plus a front tab.  The tab is what lets the title plaque and
    # the QR pad sit on solid material instead of overhanging the rim.
    _prism_xy(mesh, _base_outline(base_radius, tab_front), 0.0, top)
    _cylinder(mesh, (0.0, 0.0, top - 0.1), (0.0, 0.0, top + 0.5), base_radius - 1.5, segments=96)

    # Sun pedestal and sun.
    sun_radius = float((spec.get("sun") or {}).get("radius_mm") or 20.0)
    pedestal = float((spec.get("sun") or {}).get("pedestal_mm") or 6.0)
    _cylinder(mesh, (0.0, 0.0, top), (0.0, 0.0, top + pedestal), 10.0, segments=40)
    sun_centre = (0.0, 0.0, top + pedestal + sun_radius)
    _sphere(mesh, sun_centre, sun_radius, slices=40, stacks=24)

    # Orbit rings.
    for planet in spec.get("planets") or []:
        orbit = float(planet["orbit_mm"])
        _ring(mesh, (0.0, 0.0), orbit + 1.3, orbit - 1.3, top, top + ORBIT_HEIGHT_MM, segments=96)

    labels: list[dict[str, Any]] = []
    flags: list[dict[str, Any]] = []
    for index, planet in enumerate(spec.get("planets") or []):
        orbit = float(planet["orbit_mm"])
        angle = math.radians(float(planet["angle_deg"]))
        radius = float(planet["radius_mm"])
        x = math.cos(angle) * orbit
        y = math.sin(angle) * orbit
        centre_z = top + 34.0 + radius
        centre = (x, y, centre_z)

        # Support post from the base to the planet's lower surface.
        _cylinder(mesh, (x, y, top - 0.1), (x, y, centre_z - radius + 0.2), SUPPORT_RADIUS_MM, segments=20)
        _sphere(mesh, centre, radius, slices=32, stacks=20)

        if planet.get("id") == "saturn":
            _ring(mesh, (x, y), radius * 1.85, radius * 1.28, centre_z - 0.6, centre_z + 0.6, segments=48)

        # A tall braille name flag just outside the planet.  Alternate the
        # height so neighbouring flags on the crowded inner orbits do not
        # intersect; the user can still rotate the round base to read each one.
        tangent = (-math.sin(angle), math.cos(angle), 0.0)
        radial = (math.cos(angle), math.sin(angle), 0.0)
        label = str(planet.get("name_zh") or "")
        text_width = cnbraille.width(label, syllable_gap_mm=cnbraille.SYLLABLE_GAP_MM)
        flag_width = max(16.0, text_width + 4.0)
        flag_height = 11.0
        flag_thickness = 1.6
        z_offset = 0.0 if index % 2 == 0 else 12.0
        flag_distance = radius + 2.2 + flag_thickness / 2.0
        flag_centre = (
            x + radial[0] * flag_distance,
            y + radial[1] * flag_distance,
            centre_z + z_offset,
        )
        frame = Frame(origin=flag_centre, u=tangent, v=(0.0, 0.0, 1.0), w=radial)
        _oriented_plate(mesh, frame, flag_width, flag_height, flag_thickness)
        # Bridge from the planet surface to the flag's inner face.
        bridge_start = (
            x + radial[0] * max(0.0, radius * 0.85),
            y + radial[1] * max(0.0, radius * 0.85),
            centre_z + z_offset * 0.35,
        )
        bridge_end = (
            flag_centre[0] - radial[0] * flag_thickness / 2.0,
            flag_centre[1] - radial[1] * flag_thickness / 2.0,
            flag_centre[2],
        )
        _frustum(mesh, bridge_start, bridge_end, 1.0, 1.0, segments=12)
        dots = _braille_on_plate(mesh, frame, label, flag_width, flag_height, flag_thickness)
        labels.append(
            {
                "planet": planet.get("id"),
                "text": label,
                "cells": [list(cell) for cell in cnbraille.encode_text(label)],
                "cell_count": len(cnbraille.encode_text(label)),
                "flag_mm": [round(flag_width, 2), round(flag_height, 2), flag_thickness],
                "dots": len(dots),
            }
        )
        flags.append(
            {
                "planet": planet.get("id"),
                "centre_mm": [round(value, 2) for value in flag_centre],
                "z_offset_mm": z_offset,
            }
        )

    # Title plaque and QR pad sit side by side on the front tab.  Both tops are
    # above the orbit rings, so a ring that passes underneath cannot break the
    # flat reading or scanning surface.
    plaque_width = 72.0
    plaque_depth = 20.0
    plaque_left = -56.0
    plaque_front = tab_front + 4.0
    _box_xy(mesh, plaque_left, plaque_front, plaque_width, plaque_depth, top - 0.1, top + 2.2, chamfer=2.0)
    _emboss_text_on_top(mesh, "SOLAR SYSTEM", plaque_left + 4.0, plaque_front + 5.0, top + 2.0, top + 2.9, 4.2)
    _braille_on_top(mesh, "太阳系", plaque_left + 6.0, plaque_front + 11.0, top + 2.0, top + 2.75)

    qr_size = 32.0
    qr_left = 24.0
    qr_front = tab_front + 4.0
    _box_xy(mesh, qr_left, qr_front, qr_size, qr_size, top - 0.1, top + 1.8, chamfer=2.0)
    _emboss_text_on_top(mesh, "QR", qr_left + 4.0, qr_front + 10.0, top + 1.7, top + 2.4, 4.0)

    bounds = mesh.bounds()
    size = [bounds[3] - bounds[0], bounds[4] - bounds[1], bounds[5] - bounds[2]]
    meta = {
        "kind": "solar_system",
        "title": spec.get("title"),
        "title_zh": spec.get("title_zh"),
        "planet_count": len(spec.get("planets") or []),
        "base_mm": [round(base_radius * 2.0, 2), round(base_radius - tab_front, 2), round(base_thickness, 2)],
        "base_tab_mm": round(abs(tab_front) - base_radius, 2),
        "orbit_radii_mm": [round(float(planet["orbit_mm"]), 2) for planet in spec.get("planets") or []],
        "planets": [
            {
                "id": planet.get("id"),
                "name_zh": planet.get("name_zh"),
                "name_en": planet.get("name_en"),
                "radius_mm": round(float(planet["radius_mm"]), 3),
                "relative_radius": planet.get("relative_radius"),
                "orbit_mm": planet.get("orbit_mm"),
                "angle_deg": planet.get("angle_deg"),
            }
            for planet in spec.get("planets") or []
        ],
        "braille": {
            "standard": "GF 0019-2018",
            "labels": labels,
            "dot_diameter_mm": cnbraille.DOT_DIAMETER_MM,
            "dot_height_mm": BRAILLE_DOT_HEIGHT_MM,
            "note": "中文盲文按 GF 0019-2018 二级标调编码；行星名牌竖立在行星外侧，可旋转底座逐块摸读。",
        },
        "flags": flags,
        "qr_pad_mm": qr_size,
        "scale_note": spec.get("scale_note"),
        "size_mm": [round(value, 3) for value in size],
        "watertight": mesh.is_watertight(),
        "triangles": mesh.triangle_count(),
        "volume_mm3": round(mesh.volume(), 3),
    }
    return Model3DResult(mesh, meta)


# ---------------------------------------------------------------------------
# Generic assembly compiler
# ---------------------------------------------------------------------------


def _assembly_mesh(spec: dict[str, Any], *, max_height_mm: float = 180.0) -> Model3DResult:
    mesh = Mesh([])
    base = spec.get("base") or {}
    base_radius = float(base.get("radius_mm") or 90.0)
    base_thickness = float(base.get("thickness_mm") or 4.0)
    top = base_thickness
    _cylinder(mesh, (0.0, 0.0, 0.0), (0.0, 0.0, top), base_radius, segments=80)
    _cylinder(mesh, (0.0, 0.0, top - 0.1), (0.0, 0.0, top + 0.5), base_radius - 1.5, segments=80)

    usable = base_radius * 0.78
    size_scale = base_radius * 1.35
    parts = spec.get("parts") or []
    placed: list[dict[str, Any]] = []
    for index, part in enumerate(parts):
        size = part.get("size") or [20, 20, 20]
        position = part.get("position") or [50, 50, 0]
        # 0-100 -> centred coordinates; z 0-100 -> above the base.
        x = (float(position[0]) - 50.0) / 50.0 * usable
        y = (float(position[1]) - 50.0) / 50.0 * usable
        z = top + max(0.0, float(position[2]) / 100.0 * max_height_mm)
        sx = max(1.0, float(size[0]) / 100.0 * size_scale)
        sy = max(1.0, float(size[1]) / 100.0 * size_scale)
        sz = max(1.0, float(size[2]) / 100.0 * max_height_mm)
        # Keep every part inside the round base; an LLM may place a large part
        # at the edge of the 0-100 frame, which would otherwise float in air.
        radial_extent = max(sx, sy) / 2.0
        radial_limit = max(0.0, base_radius - radial_extent - 2.0)
        raw_radius = math.hypot(x, y)
        if raw_radius > radial_limit > 0.0:
            scale = radial_limit / raw_radius
            x *= scale
            y *= scale
        shape = part["shape"]
        if shape == "sphere":
            radius = max(sx, sy, sz) / 2.0
            centre = (x, y, z + radius)
            _sphere(mesh, centre, radius, slices=28, stacks=18)
            bottom = centre[2] - radius
            top_z = centre[2] + radius
        elif shape == "cone":
            radius = max(sx, sy) / 2.0
            _frustum(mesh, (x, y, z), (x, y, z + sz), radius, 0.0, segments=32)
            bottom, top_z = z, z + sz
        elif shape == "torus":
            outer = max(sx, sy) / 2.0
            inner = outer * 0.62
            _ring(mesh, (x, y), outer, inner, z, z + max(1.5, sz * 0.2), segments=48)
            bottom, top_z = z, z + max(1.5, sz * 0.2)
        elif shape == "plate":
            _box_xy(mesh, x - sx / 2.0, y - sy / 2.0, sx, sy, z, z + max(1.0, sz * 0.2), chamfer=1.0)
            bottom, top_z = z, z + max(1.0, sz * 0.2)
        elif shape == "box":
            _box_xy(mesh, x - sx / 2.0, y - sy / 2.0, sx, sy, z, z + sz, chamfer=0.8)
            bottom, top_z = z, z + sz
        else:
            _frustum(mesh, (x, y, z), (x, y, z + sz), max(1.0, sx / 2.0), max(1.0, sy / 2.0), segments=32)
            bottom, top_z = z, z + sz
        if bottom > top + 0.5:
            _cylinder(mesh, (x, y, top - 0.1), (x, y, bottom + 0.2), 1.5, segments=16)
        placed.append(
            {
                "id": part.get("id"),
                "name_zh": part.get("name_zh"),
                "shape": shape,
                "centre_mm": [round(x, 2), round(y, 2), round((bottom + top_z) / 2.0, 2)],
                "size_mm": [round(sx, 2), round(sy, 2), round(top_z - bottom, 2)],
            }
        )

    # A braille title flag on the front of the base, plus one name flag per
    # part around the rim.  All flags use the same counter-clockwise tangent, so
    # a reader can rotate the base to the front and read every label in the
    # normal left-to-right direction.
    label = str(spec.get("title_zh") or "模型")[:8]
    labels_meta: list[dict[str, Any]] = []
    try:
        width = max(24.0, cnbraille.width(label, syllable_gap_mm=cnbraille.SYLLABLE_GAP_MM) + 4.0)
        frame = Frame(origin=(-18.0, -base_radius + 4.0, top + 5.4), u=(1.0, 0.0, 0.0), v=(0.0, 0.0, 1.0), w=(0.0, -1.0, 0.0))
        _oriented_plate(mesh, frame, width, 11.0, 1.6)
        _braille_on_plate(mesh, frame, label, width, 11.0, 1.6)
        labels_meta.append(
            {
                "kind": "title",
                "text": label,
                "cells": [list(cell) for cell in cnbraille.encode_text(label)],
                "cell_count": len(cnbraille.encode_text(label)),
                "flag_mm": [round(width, 2), 11.0, 1.6],
            }
        )
    except (Model3DError, cnbraille.BrailleError):
        pass

    part_slots: list[tuple[dict[str, Any], str, float]] = []
    for part in placed:
        text = str(part.get("name_zh") or part.get("id") or "")[:4]
        if not text:
            continue
        try:
            text_width = cnbraille.width(text, syllable_gap_mm=cnbraille.SYLLABLE_GAP_MM)
        except cnbraille.BrailleError:
            continue
        part_slots.append((part, text, max(20.0, text_width + 4.0)))

    if part_slots:
        flag_radius = base_radius + 1.4
        # Leave the front arc free for the title flag.
        start_deg = -55.0
        end_deg = 235.0
        gap_mm = 5.0
        tiers: list[list[tuple[dict[str, Any], str, float, float]]] = [[]]
        cursor = start_deg
        for part, text, flag_width in part_slots:
            half_angle = math.degrees(flag_width / 2.0 / flag_radius)
            if cursor + 2.0 * half_angle > end_deg and tiers[-1]:
                tiers.append([])
                cursor = start_deg
            angle = cursor + half_angle
            tiers[-1].append((part, text, flag_width, angle))
            cursor = angle + half_angle + math.degrees(gap_mm / flag_radius)

        flag_height = 10.0
        flag_thickness = 1.6
        for tier_index, slots in enumerate(tiers):
            z_centre = top + 1.0 + flag_height / 2.0 + tier_index * (flag_height + 2.4)
            for part, text, flag_width, angle_deg in slots:
                theta = math.radians(angle_deg)
                radial = (math.cos(theta), math.sin(theta), 0.0)
                tangent = (-math.sin(theta), math.cos(theta), 0.0)
                flag_x = flag_radius * math.cos(theta)
                flag_y = flag_radius * math.sin(theta)
                frame = Frame(origin=(flag_x, flag_y, z_centre), u=tangent, v=(0.0, 0.0, 1.0), w=radial)
                _oriented_plate(mesh, frame, flag_width, flag_height, flag_thickness)
                try:
                    dots = _braille_on_plate(mesh, frame, text, flag_width, flag_height, flag_thickness)
                except (Model3DError, cnbraille.BrailleError):
                    dots = []
                flag_bottom = z_centre - flag_height / 2.0
                if flag_bottom > top + 0.6:
                    _cylinder(
                        mesh,
                        (flag_x, flag_y, top - 0.1),
                        (flag_x, flag_y, flag_bottom + 0.2),
                        1.5,
                        segments=12,
                    )
                labels_meta.append(
                    {
                        "kind": "part",
                        "part": part.get("id"),
                        "text": text,
                        "cells": [list(cell) for cell in cnbraille.encode_text(text)],
                        "cell_count": len(cnbraille.encode_text(text)),
                        "dots": len(dots),
                        "flag_mm": [round(flag_width, 2), flag_height, flag_thickness],
                        "angle_deg": round(angle_deg, 2),
                        "tier": tier_index,
                    }
                )

    _emboss_text_on_top(mesh, spec.get("title") or "MODEL", -base_radius + 12.0, base_radius - 32.0, top - 0.1, top + 0.8, 3.6)

    bounds = mesh.bounds()
    size = [bounds[3] - bounds[0], bounds[4] - bounds[1], bounds[5] - bounds[2]]
    meta = {
        "kind": "assembly",
        "title": spec.get("title"),
        "title_zh": spec.get("title_zh"),
        "base_mm": [round(base_radius * 2.0, 2), round(base_radius * 2.0, 2), round(base_thickness, 2)],
        "parts": placed,
        "braille": {
            "standard": "GF 0019-2018",
            "labels": labels_meta,
            "dot_diameter_mm": cnbraille.DOT_DIAMETER_MM,
            "note": "部件名称刻在底座外缘的竖立名牌上，所有名牌使用同一逆时针切线方向；旋转底座即可逐块从左到右摸读。",
        },
        "scale_note": spec.get("scale_note"),
        "size_mm": [round(value, 3) for value in size],
        "watertight": mesh.is_watertight(),
        "triangles": mesh.triangle_count(),
        "volume_mm3": round(mesh.volume(), 3),
    }
    return Model3DResult(mesh, meta)


def build_model3d(spec: dict[str, Any], *, target_height_mm: float | None = None) -> Model3DResult:
    if not isinstance(spec, dict):
        raise Model3DError("三维模型规格必须是对象。")
    kind = str(spec.get("kind") or "assembly")
    if kind == "solar_system":
        return _solar_system_mesh(spec)
    result = _assembly_mesh(spec)
    if target_height_mm:
        bounds = result.mesh.bounds()
        height = bounds[5] - bounds[2]
        if height > 1e-6:
            scale = min(1.0, float(target_height_mm) / height)
            if scale < 1.0:
                result.mesh = Mesh(
                    [
                        (
                            (a[0] * scale, a[1] * scale, a[2] * scale),
                            (b[0] * scale, b[1] * scale, b[2] * scale),
                            (c[0] * scale, c[1] * scale, c[2] * scale),
                        )
                        for a, b, c in result.mesh.triangles
                    ]
                )
                result.meta["scale"] = scale
                result.meta["size_mm"] = [round(value * scale, 3) for value in result.meta["size_mm"]]
    return result


def model3d_narration(spec: dict[str, Any], meta: dict[str, Any]) -> dict[str, Any]:
    title = spec.get("title_zh") or "三维触觉模型"
    kind = spec.get("kind")
    if kind == "solar_system":
        intro = f"这是一个{title}触觉模型。底座是圆形，中央最大的球体是太阳。"
        steps = ["先摸圆形底座的外缘，确认模型的方向；底座前方有一块标题盲文牌。"]
        for index, planet in enumerate(spec.get("planets") or [], start=1):
            steps.append(
                f"从中心向外数第 {index} 条轨道上是{planet.get('name_zh')}，"
                f"球体半径约 {float(planet.get('radius_mm') or 0):.1f} 毫米；它外侧的竖牌上写着中文盲文名字。"
            )
        steps.append("土星外面还有一圈光环，可以沿着球体赤道方向摸到。")
        outro = (
            "行星大小经过压缩，只保持真实大小的顺序，不是等比例模型；"
            "轨道表达相对位置，不表示真实距离。中文盲文按 GF 0019-2018 编码。"
        )
        return {"intro": intro, "steps": steps, "outro": outro}
    intro = f"这是一个{title}触觉模型。先摸底板，再按部件顺序触摸。"
    steps = ["先确认底板方向，再从底座前缘的盲文标题开始。"]
    for index, part in enumerate(spec.get("parts") or [], start=1):
        name = part.get("name_zh") or part.get("id")
        shape = SHAPE_NAMES.get(str(part.get("shape") or ""), str(part.get("shape") or "部件"))
        steps.append(f"第 {index} 个部件是{name}，形状是{shape}。")
    outro = "部件大小是相对比例，不是工程尺寸；需要用支撑的地方已由编译器加立柱。"
    return {"intro": intro, "steps": steps, "outro": outro}


def braille_summary(text: str) -> dict[str, Any]:
    """Small helper for the UI: show readings and cells without a printer."""
    try:
        return {"ok": True, "readings": cnbraille.readings(text), "rows": cnbraille.describe(text)}
    except (cnbraille.BrailleError, ValueError) as error:
        return {"ok": False, "message": str(error)}


def companion_scene(spec: dict[str, Any], meta: dict[str, Any] | None = None) -> dict[str, Any]:
    """Build a 2-D overview plate for the same request.

    The plate is deliberately a schematic: it shows position, order and names,
    not a projection of the printed model.  That keeps the tactile-book
    promise honest and gives a reader who cannot see the model a way to study
    the layout before touching the object.
    """
    kind = str(spec.get("kind") or "assembly")
    title = str(spec.get("title") or "TACTILE 3D MODEL")[:28]
    title_zh = str(spec.get("title_zh") or "三维模型")[:28]
    blocks: list[dict[str, Any]] = []
    order: list[str] = []

    if kind == "solar_system":
        planets = spec.get("planets") or []
        orbit_values = [float(item.get("orbit_mm") or 0.0) for item in planets]
        outer = max(orbit_values) if orbit_values else 94.0
        scale = 40.0 / max(outer, 1.0)
        centre = (50.0, 50.0)
        rings = []
        for planet in planets:
            radius = float(planet.get("orbit_mm") or 0.0) * scale
            rings.append({"type": "circle", "cx": 50.0, "cy": 50.0, "r": round(radius, 3), "width": 1.2})
        blocks.append(
            {
                "id": "orbits",
                "label": "ORBITS",
                "label_zh": "轨道",
                "note": "七条同心类圆形轨道，从内到外表示由近到远的顺序。",
                "marker": [50.0, 8.0],
                "show_label": False,
                "primitives": rings,
            }
        )
        blocks.append(
            {
                "id": "sun",
                "label": "SUN",
                "label_zh": "太阳",
                "note": "中心最大的圆是太阳。",
                "marker": [50.0, 50.0],
                "show_label": True,
                "primitives": [
                    {"type": "circle", "cx": 50.0, "cy": 50.0, "r": 7.0, "width": 2.0},
                    {"type": "text", "x": 45.0, "y": 48.0, "text": "SUN", "height": 3.2},
                    {"type": "braille", "x": 47.0, "y": 54.0, "text": "SUN"},
                ],
            }
        )
        order.append("sun")
        for index, planet in enumerate(planets, start=1):
            angle = math.radians(float(planet.get("angle_deg") or 0.0))
            orbit = float(planet.get("orbit_mm") or 0.0) * scale
            radius = max(1.6, min(7.0, float(planet.get("radius_mm") or 4.0) * 0.52))
            x = centre[0] + math.cos(angle) * orbit
            y = centre[1] + math.sin(angle) * orbit
            name = str(planet.get("name_en") or planet.get("id") or f"P{index}").upper()[:8]
            primitives = [
                {"type": "circle", "cx": round(x, 3), "cy": round(y, 3), "r": round(radius, 3), "width": 1.8},
                {"type": "braille", "x": round(x - 2.0, 3), "y": round(y + radius + 1.0, 3), "text": str(index)},
            ]
            blocks.append(
                {
                    "id": str(planet.get("id") or f"planet_{index}"),
                    "label": name,
                    "label_zh": str(planet.get("name_zh") or name),
                    "note": str(planet.get("note") or ""),
                    "marker": [round(x, 3), round(y, 3)],
                    "show_label": True,
                    "primitives": primitives,
                }
            )
            order.append(str(planet.get("id") or f"planet_{index}"))
        subtitle = f"TACTILE OVERVIEW / {len(planets)} PLANETS / NOT TO SCALE"
        footer = ["ORBIT ORDER, NOT TRUE DISTANCE", "SCAN QR FOR AUDIO"]
        notes = [
            "这张板是太阳系的结构总览：同心圆表示轨道顺序，圆点表示行星位置，不表示真实距离和大小。",
            "行星名称用拉丁字母，数字盲文标出阅读顺序；完整中文盲文名称在三维模型的名牌上。",
        ]
    else:
        parts = spec.get("parts") or []
        for index, part in enumerate(parts[:12], start=1):
            position = part.get("position") or [50.0, 50.0, 0.0]
            x = max(10.0, min(90.0, float(position[0])))
            y = max(10.0, min(88.0, float(position[1])))
            size = part.get("size") or [20.0, 20.0, 20.0]
            span = max(6.0, min(22.0, float(size[0]) * 0.30))
            shape = str(part.get("shape") or "box")
            if shape in {"sphere", "torus"}:
                primitive = {"type": "circle", "cx": round(x, 3), "cy": round(y, 3), "r": round(span / 2.0, 3), "width": 1.8}
            elif shape == "cone":
                primitive = {
                    "type": "polygon",
                    "points": [[round(x, 3), round(y - span / 2.0, 3)], [round(x + span / 2.0, 3), round(y + span / 2.0, 3)], [round(x - span / 2.0, 3), round(y + span / 2.0, 3)]],
                    "width": 1.8,
                }
            else:
                primitive = {
                    "type": "rect",
                    "x": round(x - span / 2.0, 3),
                    "y": round(y - span / 2.0, 3),
                    "w": round(span, 3),
                    "h": round(span, 3),
                    "width": 1.8,
                }
            label = str(part.get("name_en") or part.get("id") or f"PART {index}").upper()[:10]
            blocks.append(
                {
                    "id": str(part.get("id") or f"part_{index}"),
                    "label": label,
                    "label_zh": str(part.get("name_zh") or label),
                    "note": str(part.get("note") or ""),
                    "marker": [round(x, 3), round(y, 3)],
                    "show_label": True,
                    "primitives": [
                        primitive,
                        {"type": "braille", "x": round(x - 2.0, 3), "y": round(y + span / 2.0 + 1.0, 3), "text": str(index)},
                    ],
                }
            )
            order.append(str(part.get("id") or f"part_{index}"))
        subtitle = f"STRUCTURE OVERVIEW / {len(blocks)} PARTS / NOT TO SCALE"
        footer = ["PART ORDER, NOT TRUE SIZE", "SCAN QR FOR AUDIO"]
        notes = [
            "这张板是三维模型的结构总览：只标出部件位置和阅读顺序，不还原立体表面。",
            "部件的实际形状、相对大小和中文盲文名称以三维模型为准。",
        ]

    return {
        "version": 1,
        "title": title,
        "title_zh": title_zh,
        "subtitle": subtitle,
        "blocks": blocks,
        "reading_order": order,
        "footer_lines": footer,
        "notes": notes,
        "scale_note": "SCHEMATIC / NOT TO SCALE",
    }
