# 把 v0.3.0 更新到阿里云 ECS

目标服务器：`47.103.61.115`（上海，2 vCPU / 2 GiB，IP 模式，端口 8765）

这次更新包含：

- 照片级 3D 重建接入腾讯云 TokenHub（`hy-3d-3.1`，可与文本模型共用 Key）
- 触觉教材 / 触觉 3D 模型 / 照片级重建三模式
- 扫描 PDF、中文盲文、A5–A3 自动板面

下面命令都在服务器上执行，只有第 1 步在本机执行。

## 1. 本机上传发布包

发布包已经生成：`touchlearn-0.3.0.tar.gz`。

```bash
scp touchlearn-0.3.0.tar.gz root@47.103.61.115:/root/
```

如果本机没有配置 SSH 密钥，`scp` 会提示输入服务器密码。

## 2. 登录服务器并找到现有项目目录

```bash
ssh root@47.103.61.115
find / -maxdepth 5 -name "docker-compose.ip.yml" 2>/dev/null
```

记下输出中的目录，例如 `/root/touchlearn-fudan-Team_Stella`。下文的 `APP_DIR` 都指这个目录。

```bash
APP_DIR=/root/touchlearn-fudan-Team_Stella   # 按上一步结果修改
cd "$APP_DIR"
ls deploy/.env deploy/docker-compose.ip.yml
```

## 3. 备份配置和账号库

```bash
cp deploy/.env "/root/touchlearn-env-$(date +%F-%H%M).bak"

docker run --rm \
  -v touchlearn-outputs:/data \
  -v /root:/backup \
  alpine tar czf /backup/touchlearn-outputs-$(date +%F-%H%M).tar.gz -C /data .
```

第一条备份环境变量，第二条备份账号库和所有历史作业。确认 `/root` 下出现两个备份文件后再继续。

## 4. 解压新版本代码

发布包不包含 `.env`，不会覆盖你的密钥。

```bash
cd "$APP_DIR"
tar -xzf /root/touchlearn-0.3.0.tar.gz -C "$APP_DIR"
```

解压后确认版本：

```bash
grep '__version__' src/touchlearn/__init__.py
# 应输出 __version__ = "0.3.0"
```

## 5. 修改 `deploy/.env`

```bash
nano deploy/.env
```

确认或补充以下几项（不要改已有密码和验证码配置）：

```dotenv
DEPLOY_MODE=ip
TOUCHLEARN_PUBLIC_URL=http://47.103.61.115:8765
TOUCHLEARN_AUTH_DEV_MODE=false

# 文本与视觉模型：TokenHub 与 DeepSeek 二选一
TOUCHLEARN_LLM_PROVIDER=tokenhub
TOUCHLEARN_LLM_KEY=你的TokenHub密钥
TOUCHLEARN_LLM_MODEL=deepseek-v4.1-flash
TOUCHLEARN_VLM_PROVIDER=tokenhub
TOUCHLEARN_VLM_MODEL=deepseek/deepseek-flash
TOUCHLEARN_LLM_TIMEOUT=120

# 照片级 3D 重建：复用同一个 TokenHub Key
TOUCHLEARN_3D_PROVIDER=tokenhub
TOUCHLEARN_3D_KEY=
TOUCHLEARN_3D_MODEL=hy-3d-3.1
TOUCHLEARN_3D_FACES=300000
TOUCHLEARN_3D_TIMEOUT=600
TOUCHLEARN_3D_POLL=4
```

重点：

- `TOUCHLEARN_3D_KEY` 留空即可，TokenHub 会自动复用 `TOUCHLEARN_LLM_KEY`。
- TokenHub 路径使用上传照片中的第一张做单图重建；需要多角度融合时把 provider 改成 `tripo`。
- 宿主机 shell 里 `export` 的变量不会自动进入容器。密钥必须写进 `deploy/.env`，或者写进 compose 的 `environment`，然后重建容器。
- 未登录访问 `/api/health` 时，`llm` / `vision` / `reconstruction` 会统一显示 `locked`，这是隐私保护，不代表 Key 没配好。部署后用第 7 步的容器内命令确认真实状态。

## 6. 重建并启动

```bash
cd "$APP_DIR/deploy"
docker compose --env-file .env -f docker-compose.ip.yml up -d --build --remove-orphans
docker compose --env-file .env -f docker-compose.ip.yml ps
```

首次构建约 3–8 分钟。看到 `touchlearn` 状态为 `healthy` 即成功。

## 7. 验证

```bash
curl -s http://127.0.0.1:8765/api/health | python3 -m json.tool
```

应看到：

```json
{
  "ok": true,
  "version": "0.3.0",
  "public_base_url": "http://47.103.61.115:8765"
}
```

再检查容器内的三维配置（不会输出密钥）：

```bash
docker compose --env-file .env -f docker-compose.ip.yml exec touchlearn \
  python -c "import json; from touchlearn.agent.reconstruct import reconstruction_status as s; print(json.dumps(s(), ensure_ascii=False, indent=2))"
```

应看到：

```json
{
  "configured": true,
  "provider": "tokenhub",
  "label": "腾讯云 TokenHub",
  "model": "hy-3d-3.1"
}
```

浏览器访问 `http://47.103.61.115:8765`，登录后：

1. 先跑一次“触觉教材生成”，确认原有功能正常；
2. 再选“照片级 3D 重建”，上传一张主体清晰、背景干净的照片；
3. 确认卡里填高度、底座、盲文名称，提交；
4. TokenHub 通常 2–5 分钟返回，页面会依次显示排队、生成、下载、解析、组装的进度；
5. 下载 `model_textured.glb`（带纹理）和 `model.stl`（可打印），用 Bambu Studio / PrusaSlicer / Cura 打开 STL 检查。

## 8. 回滚

如果新版本启动失败：

```bash
cd "$APP_DIR"
# 恢复旧代码：用更新前的备份或 git 记录
git status
git stash list
# 恢复环境变量
cp /root/touchlearn-env-YYYY-MM-DD-HHMM.bak deploy/.env
cd deploy
docker compose --env-file .env -f docker-compose.ip.yml up -d --build --remove-orphans
```

账号库在 Docker 卷 `touchlearn-outputs` 里，重建容器不会删除。只有执行 `docker volume rm touchlearn-outputs` 才会删，不要执行。

## 9. 常见问题

**构建时 pip 很慢**：在 `deploy/.env` 加一行

```dotenv
PIP_INDEX_URL=https://mirrors.aliyun.com/pypi/simple/
```

**TokenHub 返回 `InvalidResultFormat`**：`result_format` 必须是大写 `GLB`，当前代码已固定，不需要手动改。

**TokenHub 返回 401 / 403**：`deploy/.env` 里的 `TOUCHLEARN_LLM_KEY` 不是有效的 TokenHub Key，或 Key 没有开通 3D 模型权限。

**照片超过 6 MB**：TokenHub 会拒绝。先在本地压缩到 6 MB 以内，或换一张更小的照片。

**任务超时**：默认 600 秒。排队高峰可能超过，任务 ID 24 小时内有效；把 `TOUCHLEARN_3D_TIMEOUT` 调到 900 再重试。

**内存不足**：30 万面 GLB 解析约占 300–500 MB，2 GiB 机器够用。若同时多人重建，建议把 `TOUCHLEARN_3D_FACES` 降到 150000。
