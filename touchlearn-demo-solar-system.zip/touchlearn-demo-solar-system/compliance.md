# 合规检查报告

- 输出模式：`model3d`
- 可打印（无 FAIL）：`true`
- 完全合规（无 FAIL / DEVIATION / NEEDS_REVIEW）：`false`
- 计数：{'PASS': 8, 'NEEDS_REVIEW': 2, 'DEVIATION': 1}

## 判定口径

`printable` 只表示几何没有阻断打印的 FAIL；`standards_clear` 还要求没有偏离项和待人工复核项。两者不能混为一谈。

## 检查项

| 状态 | 规则 | 实测 | 说明 |
|---|---|---|---|
| PASS | `mesh.volume` | 377715.3 mm³ | 体积为正 |
| PASS | `mesh.watertight` | yes | 每条边恰好两个三角形 |
| PASS | `mesh.min_feature` | 0.240 mm | 最小网格边高于数值退化下限 |
| PASS | `mesh.build_volume` | 203.9×220.0×68.5 mm | 尺寸在 220×220×250 mm 打印空间内 |
| NEEDS_REVIEW | `mesh.overhang` | 19.0% | 悬垂面积超过 5%，切片时建议开启树状支撑；这是工艺提示，不是模型错误。 |
| PASS | `model.qr_area` | 32.0 mm | 底座二维码平面达到 28 mm |
| PASS | `model.kind` | solar_system | 底座 + 支架 + 可触摸主体的确定性三维装配模型。 |
| PASS | `encoding.chinese_braille` | GF 0019-2018 / 7 labels / 1.6 mm dots | 中文盲文按 GF 0019-2018 二级标调编码；点径 1.6 mm，点高 0.8 mm，刻在平面名牌上。 |
| NEEDS_REVIEW | `model.braille_reachability` | vertical flags | 行星/部件名称在竖立名牌上，不是曲面刻字；需要旋转底座逐块摸读，建议在说明中写明阅读方向。 |
| DEVIATION | `model.scale` | compressed radii | 行星半径保持真实大小顺序但经过压缩，轨道只表示相对顺序；不是等比例太阳系。 |
| PASS | `audio.script` | wav + script | 讲解脚本和 WAV 均已生成 |

## 依据标准

| 标准号 | 名称 | 状态 | 实施日期 | 链接 |
|---|---|---|---|---|
| GB/T 40142-2021 | 触摸图形设计及图例 | 现行 | 2021-05-21 | https://openstd.samr.gov.cn/bzgk/std/newGbInfo?hcno=E72CE9A9B4200759B27F08F13118F5B8 |
| GB/T 39758-2021 | 无障碍设计 盲文在标志、设备和器具上的应用 | 现行 | 2021-03-09 | https://openstd.samr.gov.cn/bzgk/std/newGbInfo?hcno=63A112B519D601DBA74264AAEB314DB0 |
| GB/T 44725-2024 | 盲文出版物版式 | 现行 | 2025-02-01 | https://openstd.samr.gov.cn/bzgk/std/newGbInfo?hcno=724E7E79DD866A0D29A2EF7B1F2755B0 |
| GF 0019-2018 | 国家通用盲文方案 | 现行语言文字规范 | 2018-07-01 | http://www.moe.gov.cn/jyb_sjzl/ziliao/A19/201807/W020180725666187054299.pdf |
| 国歌盲文方案（2025） | 《中华人民共和国国歌》国家通用盲文方案 | 现行语言文字规范 | 2025-03-01 | https://www.gov.cn/yaowen/liebiao/202412/content_6990996.htm |
| GB/T 45281-2025 | 盲用多媒体信息处理技术要求 | 现行 | 2025-02-28 | https://openstd.samr.gov.cn/bzgk/std/newGbInfo?hcno=DFBB30B952CDA59D1B822398B2C00B8F |
| GB/T 45567-2025 | 信息与文献 盲用资源描述 | 现行 | 2025-11-01 | https://std.samr.gov.cn/gb/search/gbDetailed?id=33D40F11614A5D92E06397BE0A0A5B93 |
| GB/T 18028-2010 | 中国盲文数学、物理、化学符号 | 现行（复审结论：修订） | 2011-05-01 | https://std.samr.gov.cn/gb/search/gbDetailed?id=71F772D7D8D5D3A7E05397BE0A0AB82A |
| GB/T 16431-2008 | 中国盲文音乐符号 | 现行 | 2009-03-01 | https://openstd.samr.gov.cn/bzgk/std/newGbInfo?hcno=D9F2C762080DA763F452CC173F6EFC28 |
| GB/T 15720-2008 | 中国盲文 | 已废止（2025-11-03） | 2009-03-01 | https://openstd.samr.gov.cn/bzgk/std/newGbInfo?hcno=484E4150A1F62E81B0553422E6A8A292 |

## 已知限制

- 三维模型的中文名称使用 GF 0019-2018 盲文点字（1.6 mm 点径、0.8 mm 点高），刻在竖立名牌上；平面场景板仍使用 UEB 英文字母和阿拉伯数字，报告标记 `NEEDS_REVIEW`。
- GB/T 40142-2021 的公开全文只获取到封面和目录；触摸图形参数采用公开解读值，条款级核对标记为待复核。
- GB/T 15720-2008 已于 2025-11-03 废止，本报告不把它作为现行依据。
- 图片和工程图在离线模式下只作为来源留档，不凭空测量尺寸；确认后的解析式或参数才进入几何。
- 场景板只表达图块位置、连接关系和阅读顺序，不还原照片细节，也不代表真实尺寸。
