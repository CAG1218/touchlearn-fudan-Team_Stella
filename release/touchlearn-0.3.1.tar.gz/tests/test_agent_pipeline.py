from __future__ import annotations

import base64
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tests import EXAMPLES  # noqa: F401  (ensures src is on sys.path)

from touchlearn.agent.agent import TouchLearnAgent
from touchlearn.agent.router import RouteDecision
from touchlearn.agent.scene import SceneGeneration
from touchlearn.schema import has_errors, validate_payload

SELECTION_ENV = {
    "TOUCHLEARN_LLM_PROVIDER": "tokenhub",
    "TOUCHLEARN_LLM_URL": "",
    "TOUCHLEARN_LLM_KEY": "sk-test",
    "TOUCHLEARN_LLM_MODEL": "deepseek-v4.1-flash",
    "TOUCHLEARN_VLM_PROVIDER": "",
    "TOUCHLEARN_VLM_URL": "",
    "TOUCHLEARN_VLM_KEY": "",
    "TOUCHLEARN_VLM_MODEL": "",
    "TOUCHLEARN_LLM_EFFORT": "",
    "TOUCHLEARN_SCENE_MODEL": "",
    "TOUCHLEARN_SCENE_EFFORT": "",
}


class AgentPipelineTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.agent = TouchLearnAgent(output_root=Path(self.temp.name))

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_auto_route_to_scene_with_offline_template(self) -> None:
        draft = self.agent.analyze(
            {
                "subject": "auto",
                "text": "画一个串联电路示意图：电池、开关、电阻和灯泡依次连接成回路。",
            }
        )
        self.assertEqual(draft["subject"], "scene")
        self.assertTrue(draft["ready"])
        self.assertEqual(draft["fields"]["template"], "circuit")
        self.assertEqual(draft["fields"]["summary"]["block_count"], 5)
        self.assertTrue(draft["fields"]["scene"]["blocks"])
        self.assertEqual(draft["fields"]["routing"]["subject"], "scene")

    def test_scene_build_writes_printable_bundle(self) -> None:
        draft = self.agent.analyze({"subject": "auto", "text": "画一个水循环流程图：蒸发、凝结、降水、收集。"})
        self.assertEqual(draft["subject"], "scene")
        with patch("touchlearn.agent.agent.synthesize_windows_tts", return_value=(False, "test environment")):
            result = self.agent.build(draft["id"], public_base_url="http://127.0.0.1:8765")
        job_dir = Path(self.temp.name) / "jobs" / result["job_id"]
        self.assertTrue((job_dir / "model.stl").is_file())
        self.assertTrue((job_dir / "preview.svg").is_file())
        self.assertTrue((job_dir / "diagram.json").is_file())
        self.assertTrue((job_dir / "audio_script.txt").is_file())
        report = json.loads((job_dir / "compliance.json").read_text(encoding="utf-8"))
        self.assertTrue(report["printable"])
        self.assertEqual(report["counts"].get("FAIL", 0), 0)
        manifest = json.loads((job_dir / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["subject"], "scene")
        self.assertEqual(manifest["mode"], "tactile_plate")
        self.assertIn("scene_summary", manifest["geometry"])
        script = (job_dir / "audio_script.txt").read_text(encoding="utf-8")
        self.assertIn("编号 1", script)
        diagram = json.loads((job_dir / "diagram.json").read_text(encoding="utf-8"))
        issues = validate_payload(diagram)
        self.assertFalse(has_errors(issues), msg=[issue.to_dict() for issue in issues])

    def test_auto_function_from_text(self) -> None:
        draft = self.agent.analyze({"subject": "auto", "text": "请画函数 y=x^2-2x-3 的图像"})
        self.assertEqual(draft["subject"], "function")
        self.assertTrue(draft["ready"])
        self.assertIn("X^2-2X-3", draft["fields"]["expression"])

    def test_uploaded_text_document_drives_function_draft(self) -> None:
        content = "课堂练习：请画出函数 y=x^2-2x-3 的图像，并标出零点。".encode("utf-8")
        draft = self.agent.analyze(
            {
                "subject": "auto",
                "files": [{"name": "worksheet.txt", "data": base64.b64encode(content).decode("ascii")}],
            }
        )
        self.assertEqual(draft["subject"], "function")
        self.assertTrue(draft["ready"])
        self.assertIn("X^2-2X-3", draft["fields"]["expression"])
        self.assertEqual(draft["files"][0]["document"]["ok"], True)

    def test_uploaded_file_with_chinese_name_keeps_extension(self) -> None:
        content = "课堂练习：请画出函数 y=x^2-2x-3 的图像。".encode("utf-8")
        draft = self.agent.analyze(
            {
                "subject": "auto",
                "files": [{"name": "路线图.txt", "data": base64.b64encode(content).decode("ascii")}],
            }
        )
        uploaded = draft["files"][0]
        self.assertEqual(uploaded["extension"], ".txt")
        self.assertEqual(uploaded["name"], "路线图.txt")
        self.assertEqual(uploaded["document"]["ok"], True)

    def test_uploaded_image_with_chinese_name_is_accepted(self) -> None:
        draft = self.agent.analyze(
            {
                "subject": "auto",
                "files": [{"name": "尾翼图.png", "data": base64.b64encode(b"not-a-real-png").decode("ascii")}],
            }
        )
        uploaded = draft["files"][0]
        self.assertEqual(uploaded["extension"], ".png")
        self.assertEqual(uploaded["name"], "尾翼图.png")

    def test_uploaded_scene_json_is_used_directly(self) -> None:
        scene = {
            "title": "CUSTOM SCENE",
            "blocks": [
                {
                    "id": "circle",
                    "label": "CIRCLE",
                    "label_zh": "圆",
                    "primitives": [{"type": "circle", "cx": 50, "cy": 50, "r": 20}],
                }
            ],
        }
        content = json.dumps(scene, ensure_ascii=False).encode("utf-8")
        draft = self.agent.analyze(
            {
                "subject": "auto",
                "files": [{"name": "scene.json", "data": base64.b64encode(content).decode("ascii")}],
            }
        )
        self.assertEqual(draft["subject"], "scene")
        self.assertTrue(draft["ready"])
        self.assertEqual(draft["fields"]["summary"]["block_count"], 1)
        self.assertTrue(any("scene.json" in note for note in draft["notes"]))

    def test_unsupported_request_is_refused(self) -> None:
        draft = self.agent.analyze({"subject": "auto", "text": "帮我写一篇关于春天的作文"})
        self.assertEqual(draft["subject"], "unsupported")
        self.assertFalse(draft["ready"])
        self.assertTrue(draft["questions"])

    def test_explicit_template_without_text(self) -> None:
        draft = self.agent.analyze({"subject": "auto", "template": "pythagorean"})
        self.assertEqual(draft["subject"], "scene")
        self.assertTrue(draft["ready"])
        self.assertEqual(draft["fields"]["template"], "pythagorean")

    def test_scene_title_override_reaches_build(self) -> None:
        draft = self.agent.analyze({"subject": "auto", "template": "triangle"})
        scene = dict(draft["fields"]["scene"])
        scene["title"] = "RIGHT TRIANGLE"
        with patch("touchlearn.agent.agent.synthesize_windows_tts", return_value=(False, "test environment")):
            result = self.agent.build(
                draft["id"],
                overrides={"fields": {"scene": scene}},
                public_base_url="http://127.0.0.1:8765",
            )
        manifest = json.loads(
            (Path(self.temp.name) / "jobs" / result["job_id"] / "manifest.json").read_text(encoding="utf-8")
        )
        self.assertEqual(manifest["title"], "RIGHT TRIANGLE")

    def test_analyze_threads_selection_and_records_llm(self) -> None:
        decision = RouteDecision("function", 0.95, "test route")
        candidate = {
            "ok": True,
            "expression": "X^2-2X-3",
            "provider": "llm:tokenhub",
            "model": "glm-5.3",
            "confidence": 0.9,
        }
        with (
            patch.dict(os.environ, SELECTION_ENV, clear=False),
            patch("touchlearn.agent.agent.classify_request", return_value=decision) as classify,
            patch("touchlearn.agent.agent.extract_function", return_value=candidate) as extract,
        ):
            draft = self.agent.analyze(
                {
                    "subject": "auto",
                    "text": "画一个二次函数",
                    "model": "glm-5.3",
                    "effort": "high",
                }
            )
        classify_kwargs = classify.call_args.kwargs
        self.assertEqual(classify_kwargs["model"], "glm-5.3")
        self.assertEqual(classify_kwargs["effort"], "high")
        self.assertEqual(classify_kwargs["vision_model"], "deepseek/deepseek-flash")
        extract_kwargs = extract.call_args.kwargs
        self.assertEqual(extract_kwargs["model"], "glm-5.3")
        self.assertEqual(extract_kwargs["effort"], "high")
        self.assertEqual(draft["subject"], "function")
        self.assertEqual(draft["fields"]["llm"]["model"], "glm-5.3")
        self.assertEqual(draft["fields"]["llm"]["effort"], "high")
        self.assertTrue(draft["fields"]["llm"]["requested"])

    def test_analyze_records_the_initial_default(self) -> None:
        decision = RouteDecision("function", 0.95, "test route")
        candidate = {
            "ok": True,
            "expression": "sin(x)",
            "provider": "llm:tokenhub",
            "model": "deepseek-v4.1-flash",
            "confidence": 0.8,
        }
        with (
            patch.dict(os.environ, SELECTION_ENV, clear=False),
            patch("touchlearn.agent.agent.classify_request", return_value=decision),
            patch("touchlearn.agent.agent.extract_function", return_value=candidate),
        ):
            draft = self.agent.analyze({"subject": "auto", "text": "画一个正弦曲线"})
        self.assertEqual(draft["fields"]["llm"]["model"], "deepseek-v4.1-flash")
        self.assertEqual(draft["fields"]["llm"]["effort"], "low")
        self.assertFalse(draft["fields"]["llm"]["requested"])

    def test_analyze_rejects_an_unknown_model_before_calling_llm(self) -> None:
        with patch.dict(os.environ, SELECTION_ENV, clear=False):
            with self.assertRaisesRegex(ValueError, "不支持所选模型"):
                self.agent.analyze(
                    {
                        "subject": "auto",
                        "text": "画一个串联电路示意图",
                        "model": "not-offered",
                    }
                )

    def test_image_scene_uses_the_vision_model_from_the_selection(self) -> None:
        decision = RouteDecision("scene", 0.9, "test route")
        with (
            patch.dict(os.environ, SELECTION_ENV, clear=False),
            patch("touchlearn.agent.agent.classify_request", return_value=decision),
            patch(
                "touchlearn.agent.agent.generate_scene",
                return_value=SceneGeneration(False, message="stop"),
            ) as generate,
        ):
            self.agent.analyze(
                {
                    "subject": "auto",
                    "text": "把这张图简化成触觉示意图",
                    "files": [{"name": "drawing.png", "data": base64.b64encode(b"not-a-real-png").decode("ascii")}],
                    "model": "glm-5.3",
                    "effort": "medium",
                }
            )
        kwargs = generate.call_args.kwargs
        self.assertEqual(kwargs["model"], "deepseek/deepseek-flash")
        self.assertEqual(kwargs["effort"], "medium")


if __name__ == "__main__":
    unittest.main()
