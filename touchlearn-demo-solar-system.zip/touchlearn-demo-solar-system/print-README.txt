TOUCHLEARN 输出包
========================================
标题：SOLAR SYSTEM
模式：model3d

文件
- model.stl            触觉板或三维模型，可直接送入切片软件
- preview.svg          预览图（不是打印文件）
- plate_model.stl      双模式输出的配套触觉总览板（若有）
- plate_preview.svg    配套触觉板预览（若有）
- model_spec.json      三维模型的结构化规格（若有）
- qr_card.svg          A6 二维码卡片，打印后贴在预留平面
- qr.png               二维码原图
- audio_script.txt     讲解脚本
- narration.wav        讲解音频（若 TTS 成功）
- audio.html           离线播放页（与 narration.wav 同目录）
- compliance.md        合规报告
- manifest.json        可复现清单与哈希

打印建议
- 板面：3D
- 尺寸：[203.936, 220.0, 68.519] mm
- 摆放：base flat on the bed; print orbits and planets as previewed
- 喷嘴：0.4 mm；层高：0.16 mm
- 周界：3；填充：15%
- 支撑：tree supports only under tilted braille flags and long orbit bridges
- 备注：0.16 mm layers and a 0.4 mm nozzle keep the 1.6 mm braille dots legible; verify the model fits the 220×220×250 mm build volume before slicing.

二维码
二维码指向本机音频页面。手机与电脑需在同一局域网，且本地服务正在运行。
如果只在离线环境使用，可直接打开 audio.html 播放 narration.wav。

合规
先看 compliance.md。printable=true 不代表完全符合所有标准条款；DEVIATION 和 NEEDS_REVIEW 需要人工确认。
