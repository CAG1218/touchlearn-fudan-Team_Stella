from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tests import EXAMPLES  # noqa: F401  (ensures src is on sys.path)

from touchlearn import model3d
from touchlearn.agent.agent import TouchLearnAgent
from touchlearn.agent.llm import LLMResult


class AgentModel3DTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.agent = TouchLearnAgent(output_root=Path(self.temp.name))

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_both_modes_build_a_model_and_a_companion_plate(self) -> None:
        draft = self.agent.analyze(
            {
                "text": "需要一个太阳系3D模型，带底座和中文盲文标注",
                "generation_modes": ["tactile", "model3d"],
            }
        )
        self.assertEqual(draft["subject"], "model3d")
        self.assertTrue(draft["ready"])
        fields = draft["fields"]
        self.assertEqual(fields["kind"], "solar_system")
        self.assertEqual(fields["planet_count"], 7)
        self.assertEqual(fields["modes"], ["tactile", "model3d"])
        self.assertTrue(fields["companion_tactile"])
        self.assertEqual(len(fields["braille"]["labels"]), 7)

        with patch("touchlearn.agent.agent.synthesize_windows_tts", return_value=(False, "test environment")):
            result = self.agent.build(draft["id"], public_base_url="http://127.0.0.1:8765")

        job_dir = Path(self.temp.name) / "jobs" / result["job_id"]
        for name in ("model.stl", "preview.svg", "model_spec.json", "plate_model.stl", "plate_preview.svg", "plate_diagram.json"):
            self.assertTrue((job_dir / name).is_file(), name)

        manifest = json.loads((job_dir / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["subject"], "model3d")
        self.assertEqual(manifest["mode"], "model3d")
        self.assertEqual(manifest["print"]["paper"], "3D")
        self.assertEqual(manifest["geometry"]["kind"], "model3d")
        self.assertTrue(manifest["geometry"]["mesh"]["watertight"])
        self.assertEqual(manifest["geometry"]["companion"]["paper"], "A4")
        self.assertEqual(
            [item["text"] for item in manifest["geometry"]["meta"]["braille"]["labels"]],
            ["水星", "金星", "地球", "火星", "木星", "土星", "天王星"],
        )

        report = json.loads((job_dir / "compliance.json").read_text(encoding="utf-8"))
        self.assertTrue(report["printable"])
        self.assertEqual(report["counts"].get("FAIL", 0), 0)

    def test_model_only_request_skips_the_companion_plate(self) -> None:
        draft = self.agent.analyze(
            {
                "text": "做一个八大行星的太阳系3D模型",
                "generation_modes": ["model3d"],
            }
        )
        self.assertEqual(draft["subject"], "model3d")
        self.assertEqual(draft["fields"]["planet_count"], 8)
        self.assertFalse(draft["fields"]["companion_tactile"])

    def test_empty_modes_keep_the_tactile_default(self) -> None:
        draft = self.agent.analyze({"text": "画一个串联电路：电池、开关、电阻和灯泡"})
        self.assertEqual(draft["subject"], "scene")
        self.assertEqual(draft["fields"]["template"], "circuit")

    def test_model3d_retries_without_reasoning_on_length(self) -> None:
        truncated = LLMResult(False, finish_reason="length", message="truncated")
        with patch(
            "touchlearn.model3d.chat_json",
            side_effect=[truncated, truncated],
        ) as fake:
            plan = model3d.plan_model3d("做一个尾翼三维模型", effort="high")
        self.assertFalse(plan.ok)
        self.assertEqual(fake.call_count, 2)
        self.assertEqual(fake.call_args_list[0].kwargs["effort"], "high")
        self.assertEqual(fake.call_args_list[1].kwargs["effort"], "off")
        self.assertNotIn("max_tokens", fake.call_args_list[0].kwargs)


if __name__ == "__main__":
    unittest.main()
