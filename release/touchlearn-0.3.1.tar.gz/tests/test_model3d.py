from __future__ import annotations

import unittest

from tests import EXAMPLES  # noqa: F401  (ensures src is on sys.path)

from touchlearn.model3d import (
    build_model3d,
    companion_scene,
    compress_planet_radius,
    normalize_model_spec,
    solar_system_spec,
)


class SolarSystemModelTests(unittest.TestCase):
    def test_default_catalogue_has_seven_planets_in_order(self) -> None:
        spec = solar_system_spec("需要一个太阳系3D模型")
        planets = spec["planets"]
        self.assertEqual(spec["kind"], "solar_system")
        self.assertEqual(len(planets), 7)
        self.assertEqual([item["name_zh"] for item in planets[:3]], ["水星", "金星", "地球"])
        for item in planets:
            self.assertAlmostEqual(item["radius_mm"], compress_planet_radius(item["relative_radius"]), places=2)
        by_radius = sorted(planets, key=lambda item: item["relative_radius"])
        self.assertEqual([item["id"] for item in by_radius][-1], "jupiter")
        self.assertEqual([item["id"] for item in by_radius][0], "mercury")
        orbits = [item["orbit_mm"] for item in planets]
        self.assertEqual(orbits, sorted(orbits))

    def test_eight_planets_available_on_request(self) -> None:
        spec = solar_system_spec("做一个八大行星的太阳系模型")
        self.assertEqual(len(spec["planets"]), 8)

    def test_build_is_watertight_and_fits_build_volume(self) -> None:
        spec = solar_system_spec("太阳系3D模型")
        result = build_model3d(spec)
        self.assertTrue(result.mesh.is_watertight())
        width, depth, height = result.meta["size_mm"]
        self.assertLessEqual(width, 220.0 + 1e-6)
        self.assertLessEqual(depth, 220.0 + 1e-6)
        self.assertLessEqual(height, 250.0 + 1e-6)
        self.assertGreater(result.mesh.volume(), 0.0)

    def test_every_planet_has_a_chinese_braille_label(self) -> None:
        spec = solar_system_spec("太阳系3D模型")
        result = build_model3d(spec)
        labels = result.meta["braille"]["labels"]
        self.assertEqual(len(labels), 7)
        self.assertEqual([item["text"] for item in labels], [item["name_zh"] for item in spec["planets"]])
        self.assertTrue(all(item["cells"] for item in labels))

    def test_companion_scene_covers_the_same_planets(self) -> None:
        spec = solar_system_spec("太阳系3D模型")
        result = build_model3d(spec)
        scene = companion_scene(spec, result.meta)
        ids = [block["id"] for block in scene["blocks"]]
        self.assertEqual(len(ids), 1 + 1 + len(spec["planets"]))
        self.assertIn("orbits", ids)
        self.assertIn("sun", ids)


class AssemblyModelTests(unittest.TestCase):
    def test_generic_spec_is_validated_without_inventing_parts(self) -> None:
        with self.assertRaises(Exception):
            normalize_model_spec({"kind": "assembly", "title": "EMPTY"})
        spec, warnings = normalize_model_spec(
            {
                "kind": "assembly",
                "title": "WATER",
                "title_zh": "水分子",
                "parts": [
                    {"id": "o", "name_zh": "氧原子", "shape": "sphere", "size": [30, 30, 30], "position": [50, 50, 10]},
                    {"id": "h1", "name_zh": "氢原子", "shape": "sphere", "size": [18, 18, 18], "position": [38, 50, 35]},
                ],
            }
        )
        self.assertEqual(spec["kind"], "assembly")
        self.assertEqual(len(spec["parts"]), 2)
        self.assertEqual(warnings, [])

    def test_manual_assembly_has_braille_and_base(self) -> None:
        spec = {
            "version": 1,
            "kind": "assembly",
            "title": "DEMO",
            "title_zh": "演示模型",
            "parts": [
                {"id": "core", "name_zh": "核心", "shape": "sphere", "size": [24, 24, 24], "position": [0, 0, 30]},
                {"id": "arm", "name_zh": "支架", "shape": "cylinder", "size": [6, 6, 26], "position": [18, 0, 18]},
            ],
        }
        result = build_model3d(spec, target_height_mm=130.0)
        self.assertTrue(result.mesh.is_watertight())
        self.assertEqual(result.meta["kind"], "assembly")
        labels = result.meta["braille"]["labels"]
        self.assertEqual(len(labels), 3)
        self.assertEqual([item["text"] for item in labels], ["演示模型", "核心", "支架"])
        self.assertTrue(all(item["cells"] for item in labels))
        self.assertLessEqual(max(result.meta["size_mm"][2], 0.0), 130.0 + 1e-6)


if __name__ == "__main__":
    unittest.main()
